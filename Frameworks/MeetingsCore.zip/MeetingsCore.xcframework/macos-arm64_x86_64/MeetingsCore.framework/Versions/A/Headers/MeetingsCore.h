#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class MeetingsCoreViewType, MeetingsCoreMemberType, MeetingsCoreMemberRole, MeetingsCoreGetAssignPrimaryAdminMembersList, MeetingsCoreGetMeetingMemberById, MeetingsCoreGetMeetingMembers, MeetingsCoreGetMeetingMembersByIdsSortedByAudio, MeetingsCoreGetMeetingMembersExcludingGuestsWithMemberRoleNone, MeetingsCoreGetMeetingMembersExcludingStageMembers, MeetingsCoreGetMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone, MeetingsCoreGetPinnedMembers, MeetingsCoreGetSingleUserTypeMeetingMember, MeetingsCoreGetSpeakRequestMembersList, MeetingsCoreGetSpotLightMembersList, MeetingsCoreGetStreamIdsForGrid, MeetingsCoreRequestType, MeetingsCoreGetWaitingRequestMembersList, MeetingsCoreMeetingsMemberEntity, MeetingsCoreKotlinUnit, MeetingsCoreRuntimeTransacterTransaction, MeetingsCoreKotlinThrowable, MeetingsCoreRuntimeBaseTransacterImpl, MeetingsCoreRuntimeTransacterImpl, MeetingsCoreMeetingsMemberEntityAdapter, MeetingsCoreRuntimeQuery<__covariant RowType>, MeetingsCoreMeetingsMemberRingLogEntity, MeetingsCoreMeetingsMemberEntityQueries, MeetingsCoreMeetingsMemberRingLogEntityQueries, MeetingsCoreSpeakRequestMemberEntityQueries, MeetingsCoreSpotLightMemberEntityQueries, MeetingsCoreWaitingRequestMemberEntityQueries, MeetingsCoreRTCPMeetingsDatabaseCompanion, MeetingsCoreWaitingRequestMemberEntityAdapter, MeetingsCoreSpeakRequestMemberEntity, MeetingsCoreSpotLightMemberEntity, MeetingsCoreWaitingRequestMemberEntity, MeetingsCoreAudioSource, MeetingsCoreAudioSourceBLUETOOTH, MeetingsCoreAudioSourceEARPIECE, MeetingsCoreAudioSourceNONE, MeetingsCoreAudioSourceSPEAKER, MeetingsCoreRTCPAudioManagerCompanion, MeetingsCoreRTCPMeetingsClientResult<ResultType>, MeetingsCoreRTCPAudioManager, MeetingsCoreKotlinArray<T>, MeetingsCoreKotlinException, MeetingsCoreAuthException, MeetingsCoreClientAccessTokenResponseCompanion, MeetingsCoreHTTPWMSLogger, MeetingsCoreHttpLogger, MeetingsCoreLog, MeetingsCoreRTCPMeetingDebugLogging, MeetingsCoreRTCPCustomVideoCapturerManager, RTCVideoSource, MeetingsCoreRTCPMeetingsClientCompanion, MeetingsCoreVideoCaptureSpec, MeetingsCoreRTCPMeetingVideo, MeetingsCoreCameraFace, MeetingsCoreRTCPMeetingsMember, MeetingsCoreRTCPMeetingState, MeetingsCoreRTCPMeetingsConfigurations, MeetingsCoreRTCPMeetingsRemoteConfigs, MeetingsCoreRTCPWMSConfiguration, MeetingsCoreRTCPMeetingsClient, MeetingsCoreRTCPScreenShareVideoCapturerManager, RTCVideoCapturer, MeetingsCoreKotlinPair<__covariant A, __covariant B>, MeetingsCorePermissionsUtil, MeetingsCoreClientStatsResponseCompanion, MeetingsCoreClientStatsResponse, MeetingsCoreKotlinx_serialization_jsonJsonElement, MeetingsCoreGetParticipantsDetailsResponseCompanion, MeetingsCoreGetParticipantsDetailsResponse, MeetingsCoreHandleRemoveUserResponseCompanion, MeetingsCoreHandleRemoveUserResponse, MeetingsCoreRTCPMeetingsClientResultCompanion, MeetingsCoreRTCPMeetingsClientResultError, MeetingsCoreKotlinEnumCompanion, MeetingsCoreKotlinEnum<E>, MeetingsCoreAVStatusModeCompanion, MeetingsCoreAVStatusMode, MeetingsCoreAudioEnabledDisabledNotifierDataStatus, MeetingsCoreAudioEnabledDisabledNotifierData, MeetingsCoreConferenceACLCompanion, MeetingsCoreConferenceACL, MeetingsCoreCreatorDetails, MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope, MeetingsCoreEnableAudioRestrictedNotifierData, MeetingsCoreExpiryDurationRemainsData, MeetingsCoreGlobalSettings, MeetingsCoreHostDetails, MeetingsCoreMediaServerReachabilityReportMediaServerIPState, MeetingsCoreMediaServerReachabilityReportStatus, MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus, MeetingsCoreMeetingConnectionModeCompanion, MeetingsCoreMeetingConnectionMode, MeetingsCoreMeetingDetails, MeetingsCoreMeetingLayoutCompanion, MeetingsCoreMeetingLayout, MeetingsCoreMemberNotifierData, MeetingsCoreMemberRoleCompanion, MeetingsCoreUserRolesUserRoleDetails, MeetingsCoreMemberTypeCompanion, MeetingsCorePageDetail, MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail, MeetingsCorePrimaryAdminAssignedNotifierData, MeetingsCoreRTCPMeetingRequest, MeetingsCoreUIPreference, MeetingsCoreRTCPMeetingsRemoteConfigsAction, MeetingsCoreRTCPMeetingsState, MeetingsCoreRecordingNotifierDataRecordingAction, MeetingsCoreRecordingNotifierData, MeetingsCoreRemovedMemberNotifierData, MeetingsCoreRequestTypeCompanion, MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail, MeetingsCoreSecondaryAdminAssignedRemovedNotifierData, MeetingsCoreUserACLCompanion, MeetingsCoreUserACL, MeetingsCoreUserRoles, MeetingsCoreViewTypeCompanion, MeetingsCoreWaitingRoomStatus, MeetingsCoreRtcp_coreVideoStreamTrack, MeetingsCoreRtcp_coreVideoSinkDetails, NSObject, MeetingsCoreRTCPMeetingsClientException, MeetingsCoreKotlinx_serialization_jsonJson, MeetingsCoreRuntimeExecutableQuery<__covariant RowType>, MeetingsCoreRuntimeAfterVersion, MeetingsCoreKotlinRuntimeException, MeetingsCoreKotlinIllegalStateException, MeetingsCoreKotlinx_serialization_jsonJsonElementCompanion, MeetingsCoreRtcp_coreMediaStreamTrackCompanion, RTCMediaStreamTrack, MeetingsCoreRtcp_coreMediaStreamTrackKind, MeetingsCoreRtcp_coreMediaStreamTrack, MeetingsCoreRtcp_coreVideoCaptureSpec, NSView, MeetingsCoreKotlinx_serialization_coreSerializersModule, MeetingsCoreKotlinx_serialization_jsonJsonDefault, MeetingsCoreKotlinx_serialization_jsonJsonConfiguration, MeetingsCoreKotlinByteArray, MeetingsCoreKotlinx_serialization_coreSerialKind, MeetingsCoreKotlinNothing, MeetingsCoreKotlinByteIterator;

@protocol MeetingsCorePlatform, MeetingsCoreRuntimeColumnAdapter, MeetingsCoreRuntimeSqlDriver, MeetingsCoreRuntimeTransactionWithoutReturn, MeetingsCoreRuntimeTransactionWithReturn, MeetingsCoreRuntimeTransacterBase, MeetingsCoreRuntimeTransacter, MeetingsCoreRTCPMeetingsDatabase, MeetingsCoreRuntimeSqlSchema, MeetingsCoreKotlinx_coroutines_coreFlow, MeetingsCoreKotlinSuspendFunction1, MeetingsCoreKotlinx_serialization_coreKSerializer, MeetingsCoreKtor_client_loggingLogger, MeetingsCoreRtcp_coreRTCPCoreLogger, MeetingsCoreRTCPMeetingsDebugLogger, MeetingsCoreRTCPMeetingsClientLogger, MeetingsCoreKotlinComparable, MeetingsCoreKotlinx_coroutines_coreSharedFlow, MeetingsCoreKotlinx_coroutines_coreStateFlow, MeetingsCoreRuntimeQueryListener, MeetingsCoreRuntimeQueryResult, MeetingsCoreRuntimeSqlPreparedStatement, MeetingsCoreRuntimeSqlCursor, MeetingsCoreRuntimeCloseable, MeetingsCoreRuntimeTransactionCallbacks, MeetingsCoreKotlinx_coroutines_coreFlowCollector, MeetingsCoreKotlinIterator, MeetingsCoreKotlinFunction, MeetingsCoreKotlinx_serialization_coreEncoder, MeetingsCoreKotlinx_serialization_coreSerialDescriptor, MeetingsCoreKotlinx_serialization_coreSerializationStrategy, MeetingsCoreKotlinx_serialization_coreDecoder, MeetingsCoreKotlinx_serialization_coreDeserializationStrategy, MeetingsCoreKotlinx_serialization_coreSerialFormat, MeetingsCoreKotlinx_serialization_coreStringFormat, MeetingsCoreKotlinx_serialization_coreCompositeEncoder, MeetingsCoreKotlinAnnotation, MeetingsCoreKotlinx_serialization_coreCompositeDecoder, MeetingsCoreKotlinx_serialization_coreSerializersModuleCollector, MeetingsCoreKotlinKClass, MeetingsCoreKotlinx_serialization_jsonJsonNamingStrategy, MeetingsCoreKotlinKDeclarationContainer, MeetingsCoreKotlinKAnnotatedElement, MeetingsCoreKotlinKClassifier;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface MeetingsCoreBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface MeetingsCoreBase (MeetingsCoreBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface MeetingsCoreMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface MeetingsCoreMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorMeetingsCoreKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface MeetingsCoreNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface MeetingsCoreByte : MeetingsCoreNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface MeetingsCoreUByte : MeetingsCoreNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface MeetingsCoreShort : MeetingsCoreNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface MeetingsCoreUShort : MeetingsCoreNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface MeetingsCoreInt : MeetingsCoreNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface MeetingsCoreUInt : MeetingsCoreNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface MeetingsCoreLong : MeetingsCoreNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface MeetingsCoreULong : MeetingsCoreNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface MeetingsCoreFloat : MeetingsCoreNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface MeetingsCoreDouble : MeetingsCoreNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface MeetingsCoreBoolean : MeetingsCoreNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAssignPrimaryAdminMembersList")))
@interface MeetingsCoreGetAssignPrimaryAdminMembersList : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetAssignPrimaryAdminMembersList *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMeetingMemberById")))
@interface MeetingsCoreGetMeetingMemberById : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetMeetingMemberById *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMeetingMembers")))
@interface MeetingsCoreGetMeetingMembers : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetMeetingMembers *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMeetingMembersByIdsSortedByAudio")))
@interface MeetingsCoreGetMeetingMembersByIdsSortedByAudio : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetMeetingMembersByIdsSortedByAudio *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMeetingMembersExcludingGuestsWithMemberRoleNone")))
@interface MeetingsCoreGetMeetingMembersExcludingGuestsWithMemberRoleNone : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetMeetingMembersExcludingGuestsWithMemberRoleNone *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMeetingMembersExcludingStageMembers")))
@interface MeetingsCoreGetMeetingMembersExcludingStageMembers : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetMeetingMembersExcludingStageMembers *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone")))
@interface MeetingsCoreGetMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetPinnedMembers")))
@interface MeetingsCoreGetPinnedMembers : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(int64_t)pinnedSeq __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetPinnedMembers *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(int64_t)pinnedSeq __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) int64_t pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSingleUserTypeMeetingMember")))
@interface MeetingsCoreGetSingleUserTypeMeetingMember : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetSingleUserTypeMeetingMember *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString * _Nullable)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable userId_ __attribute__((swift_name("userId_")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSpeakRequestMembersList")))
@interface MeetingsCoreGetSpeakRequestMembersList : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime name:(NSString * _Nullable)name __attribute__((swift_name("init(pkId:confId:userId:addedTime:name:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetSpeakRequestMembersList *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime name:(NSString * _Nullable)name __attribute__((swift_name("doCopy(pkId:confId:userId:addedTime:name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetSpotLightMembersList")))
@interface MeetingsCoreGetSpotLightMembersList : MeetingsCoreBase
- (instancetype)initWithPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString * _Nullable)confId userId:(NSString * _Nullable)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType * _Nullable)viewType memberType:(MeetingsCoreMemberType * _Nullable)memberType role:(MeetingsCoreMemberRole * _Nullable)role audioEnabled:(MeetingsCoreBoolean * _Nullable)audioEnabled enableAudioRestricted:(MeetingsCoreBoolean * _Nullable)enableAudioRestricted videoEnabled:(MeetingsCoreBoolean * _Nullable)videoEnabled speaking:(MeetingsCoreBoolean * _Nullable)speaking ringing:(MeetingsCoreBoolean * _Nullable)ringing addedTime:(MeetingsCoreLong * _Nullable)addedTime audioWeight:(MeetingsCoreLong * _Nullable)audioWeight stagePosition:(MeetingsCoreLong * _Nullable)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString *)userId_ __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetSpotLightMembersList *)doCopyPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString * _Nullable)confId userId:(NSString * _Nullable)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType * _Nullable)viewType memberType:(MeetingsCoreMemberType * _Nullable)memberType role:(MeetingsCoreMemberRole * _Nullable)role audioEnabled:(MeetingsCoreBoolean * _Nullable)audioEnabled enableAudioRestricted:(MeetingsCoreBoolean * _Nullable)enableAudioRestricted videoEnabled:(MeetingsCoreBoolean * _Nullable)videoEnabled speaking:(MeetingsCoreBoolean * _Nullable)speaking ringing:(MeetingsCoreBoolean * _Nullable)ringing addedTime:(MeetingsCoreLong * _Nullable)addedTime audioWeight:(MeetingsCoreLong * _Nullable)audioWeight stagePosition:(MeetingsCoreLong * _Nullable)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq userId_:(NSString *)userId_ __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:userId_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCoreLong * _Nullable addedTime __attribute__((swift_name("addedTime")));
@property (readonly) MeetingsCoreBoolean * _Nullable audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) MeetingsCoreLong * _Nullable audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString * _Nullable confId __attribute__((swift_name("confId")));
@property (readonly) MeetingsCoreBoolean * _Nullable enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType * _Nullable memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) MeetingsCoreLong * _Nullable pkId __attribute__((swift_name("pkId")));
@property (readonly) MeetingsCoreBoolean * _Nullable ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole * _Nullable role __attribute__((swift_name("role")));
@property (readonly) MeetingsCoreBoolean * _Nullable speaking __attribute__((swift_name("speaking")));
@property (readonly) MeetingsCoreLong * _Nullable stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@property (readonly) NSString *userId_ __attribute__((swift_name("userId_")));
@property (readonly) MeetingsCoreBoolean * _Nullable videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType * _Nullable viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetStreamIdsForGrid")))
@interface MeetingsCoreGetStreamIdsForGrid : MeetingsCoreBase
- (instancetype)initWithUserId:(NSString *)userId gridStreamId:(NSString * _Nullable)gridStreamId __attribute__((swift_name("init(userId:gridStreamId:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetStreamIdsForGrid *)doCopyUserId:(NSString *)userId gridStreamId:(NSString * _Nullable)gridStreamId __attribute__((swift_name("doCopy(userId:gridStreamId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetWaitingRequestMembersList")))
@interface MeetingsCoreGetWaitingRequestMembersList : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId requestType:(MeetingsCoreRequestType *)requestType addedTime:(int64_t)addedTime name:(NSString * _Nullable)name __attribute__((swift_name("init(pkId:confId:userId:requestType:addedTime:name:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGetWaitingRequestMembersList *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId requestType:(MeetingsCoreRequestType *)requestType addedTime:(int64_t)addedTime name:(NSString * _Nullable)name __attribute__((swift_name("doCopy(pkId:confId:userId:requestType:addedTime:name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) MeetingsCoreRequestType *requestType __attribute__((swift_name("requestType")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((swift_name("Platform")))
@protocol MeetingsCorePlatform
@required
- (NSString *)userAgentAppName:(NSString *)appName __attribute__((swift_name("userAgent(appName:)")));
@property (readonly) NSString *osCode __attribute__((swift_name("osCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IOSPlatform")))
@interface MeetingsCoreIOSPlatform : MeetingsCoreBase <MeetingsCorePlatform>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)userAgentAppName:(NSString *)appName __attribute__((swift_name("userAgent(appName:)")));
@property (readonly) NSString *osCode __attribute__((swift_name("osCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingsMemberEntity")))
@interface MeetingsCoreMeetingsMemberEntity : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq __attribute__((swift_name("init(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreMeetingsMemberEntity *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq __attribute__((swift_name("doCopy(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) int64_t audioWeight __attribute__((swift_name("audioWeight")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) MeetingsCoreLong * _Nullable firstJoinedTime __attribute__((swift_name("firstJoinedTime")));
@property (readonly) MeetingsCoreLong * _Nullable gridPageNumber __attribute__((swift_name("gridPageNumber")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) MeetingsCoreLong * _Nullable joinedTime __attribute__((swift_name("joinedTime")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreLong * _Nullable pinnedSeq __attribute__((swift_name("pinnedSeq")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) int64_t stagePosition __attribute__((swift_name("stagePosition")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingsMemberEntity.Adapter")))
@interface MeetingsCoreMeetingsMemberEntityAdapter : MeetingsCoreBase
- (instancetype)initWithViewTypeAdapter:(id<MeetingsCoreRuntimeColumnAdapter>)viewTypeAdapter memberTypeAdapter:(id<MeetingsCoreRuntimeColumnAdapter>)memberTypeAdapter roleAdapter:(id<MeetingsCoreRuntimeColumnAdapter>)roleAdapter __attribute__((swift_name("init(viewTypeAdapter:memberTypeAdapter:roleAdapter:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<MeetingsCoreRuntimeColumnAdapter> memberTypeAdapter __attribute__((swift_name("memberTypeAdapter")));
@property (readonly) id<MeetingsCoreRuntimeColumnAdapter> roleAdapter __attribute__((swift_name("roleAdapter")));
@property (readonly) id<MeetingsCoreRuntimeColumnAdapter> viewTypeAdapter __attribute__((swift_name("viewTypeAdapter")));
@end

__attribute__((swift_name("RuntimeBaseTransacterImpl")))
@interface MeetingsCoreRuntimeBaseTransacterImpl : MeetingsCoreBase
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)createArgumentsCount:(int32_t)count __attribute__((swift_name("createArguments(count:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)notifyQueriesIdentifier:(int32_t)identifier tableProvider:(void (^)(MeetingsCoreKotlinUnit *(^)(NSString *)))tableProvider __attribute__((swift_name("notifyQueries(identifier:tableProvider:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)postTransactionCleanupTransaction:(MeetingsCoreRuntimeTransacterTransaction *)transaction enclosing:(MeetingsCoreRuntimeTransacterTransaction * _Nullable)enclosing thrownException:(MeetingsCoreKotlinThrowable * _Nullable)thrownException returnValue:(id _Nullable)returnValue __attribute__((swift_name("postTransactionCleanup(transaction:enclosing:thrownException:returnValue:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<MeetingsCoreRuntimeSqlDriver> driver __attribute__((swift_name("driver")));
@end

__attribute__((swift_name("RuntimeTransacterBase")))
@protocol MeetingsCoreRuntimeTransacterBase
@required
@end

__attribute__((swift_name("RuntimeTransacter")))
@protocol MeetingsCoreRuntimeTransacter <MeetingsCoreRuntimeTransacterBase>
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<MeetingsCoreRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<MeetingsCoreRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((swift_name("RuntimeTransacterImpl")))
@interface MeetingsCoreRuntimeTransacterImpl : MeetingsCoreRuntimeBaseTransacterImpl <MeetingsCoreRuntimeTransacter>
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<MeetingsCoreRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<MeetingsCoreRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingsMemberEntityQueries")))
@interface MeetingsCoreMeetingsMemberEntityQueries : MeetingsCoreRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver MeetingsMemberEntityAdapter:(MeetingsCoreMeetingsMemberEntityAdapter *)MeetingsMemberEntityAdapter __attribute__((swift_name("init(driver:MeetingsMemberEntityAdapter:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)changeInviteeAsParticipantConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("changeInviteeAsParticipant(confId:userId:)")));
- (void)changeInviteeAsSecondaryAdminConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("changeInviteeAsSecondaryAdmin(confId:userId:)")));
- (void)changeInviteesAsParticipantsConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("changeInviteesAsParticipants(confId:userIds:)")));
- (void)changeMemberRolesAsSecondaryAdminsConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("changeMemberRolesAsSecondaryAdmins(confId:userIds:)")));
- (void)changeSecondaryAdminsAsParticipantsConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("changeSecondaryAdminsAsParticipants(confId:userIds:)")));
- (void)clearMeetingMembers __attribute__((swift_name("clearMeetingMembers()")));
- (void)deleteMeetingMemberConfId:(NSString *)confId userId:(NSString *)userId viewType:(MeetingsCoreViewType *)viewType __attribute__((swift_name("deleteMeetingMember(confId:userId:viewType:)")));
- (void)disableMicStatusForAllConfId:(NSString *)confId excludedUserIds:(id)excludedUserIds __attribute__((swift_name("disableMicStatusForAll(confId:excludedUserIds:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getAdminsUserIdsConfId:(NSString *)confId __attribute__((swift_name("getAdminsUserIds(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetAssignPrimaryAdminMembersList *> *)getAssignPrimaryAdminMembersListConfId:(NSString *)confId __attribute__((swift_name("getAssignPrimaryAdminMembersList(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getAssignPrimaryAdminMembersListConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getAssignPrimaryAdminMembersList(confId:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)getAudioStatusByIdConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("getAudioStatusById(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getEnableAudioRestrictedMembersIdsConfId:(NSString *)confId __attribute__((swift_name("getEnableAudioRestrictedMembersIds(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMeetingsMemberEntity *> *)getGridMembersConfId:(NSString *)confId __attribute__((swift_name("getGridMembers(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getGridMembersConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable))mapper __attribute__((swift_name("getGridMembers(confId:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetMeetingMemberById *> *)getMeetingMemberByIdConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("getMeetingMemberById(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMemberByIdConfId:(NSString *)confId userId:(NSString *)userId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getMeetingMemberById(confId:userId:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMeetingsMemberEntity *> *)getMeetingMemberByIdIfOutOfStageConfId:(NSString *)confId userId:(NSString *)userId speakerCount:(int64_t)speakerCount __attribute__((swift_name("getMeetingMemberByIdIfOutOfStage(confId:userId:speakerCount:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMemberByIdIfOutOfStageConfId:(NSString *)confId userId:(NSString *)userId speakerCount:(int64_t)speakerCount mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable))mapper __attribute__((swift_name("getMeetingMemberByIdIfOutOfStage(confId:userId:speakerCount:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetMeetingMembers *> *)getMeetingMembersConfId:(NSString *)confId searchQuery:(NSString *)searchQuery __attribute__((swift_name("getMeetingMembers(confId:searchQuery:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMembersConfId:(NSString *)confId searchQuery:(NSString *)searchQuery mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getMeetingMembers(confId:searchQuery:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetMeetingMembersByIdsSortedByAudio *> *)getMeetingMembersByIdsSortedByAudioConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("getMeetingMembersByIdsSortedByAudio(confId:userIds:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMembersByIdsSortedByAudioConfId:(NSString *)confId userIds:(id)userIds mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getMeetingMembersByIdsSortedByAudio(confId:userIds:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)getMeetingMembersCountConfId:(NSString *)confId __attribute__((swift_name("getMeetingMembersCount(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)getMeetingMembersCountExcludingGuestsWithMemberRoleNoneConfId:(NSString *)confId __attribute__((swift_name("getMeetingMembersCountExcludingGuestsWithMemberRoleNone(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)getMeetingMembersCountExcludingMemberRoleNoneConfId:(NSString *)confId __attribute__((swift_name("getMeetingMembersCountExcludingMemberRoleNone(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetMeetingMembersExcludingGuestsWithMemberRoleNone *> *)getMeetingMembersExcludingGuestsWithMemberRoleNoneConfId:(NSString *)confId searchQuery:(NSString *)searchQuery __attribute__((swift_name("getMeetingMembersExcludingGuestsWithMemberRoleNone(confId:searchQuery:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMembersExcludingGuestsWithMemberRoleNoneConfId:(NSString *)confId searchQuery:(NSString *)searchQuery mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getMeetingMembersExcludingGuestsWithMemberRoleNone(confId:searchQuery:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetMeetingMembersExcludingStageMembers *> *)getMeetingMembersExcludingStageMembersConfId:(NSString *)confId speakerCount:(int64_t)speakerCount searchQuery:(NSString *)searchQuery __attribute__((swift_name("getMeetingMembersExcludingStageMembers(confId:speakerCount:searchQuery:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMembersExcludingStageMembersConfId:(NSString *)confId speakerCount:(int64_t)speakerCount searchQuery:(NSString *)searchQuery mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getMeetingMembersExcludingStageMembers(confId:speakerCount:searchQuery:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone *> *)getMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNoneConfId:(NSString *)confId speakerCount:(int64_t)speakerCount searchQuery:(NSString *)searchQuery __attribute__((swift_name("getMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone(confId:speakerCount:searchQuery:)")));
- (MeetingsCoreRuntimeQuery<id> *)getMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNoneConfId:(NSString *)confId speakerCount:(int64_t)speakerCount searchQuery:(NSString *)searchQuery mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getMeetingMembersExcludingStageMembersAndGuestsWithMemberRoleNone(confId:speakerCount:searchQuery:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMemberType *> *)getMemberTypeByIdConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("getMemberTypeById(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)getMembersAudioStatusExcludingAdminsConfId:(NSString *)confId __attribute__((swift_name("getMembersAudioStatusExcludingAdmins(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMeetingsMemberEntity *> *)getPageWiseGridMembersConfId:(NSString *)confId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber __attribute__((swift_name("getPageWiseGridMembers(confId:gridPageNumber:)")));
- (MeetingsCoreRuntimeQuery<id> *)getPageWiseGridMembersConfId:(NSString *)confId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable))mapper __attribute__((swift_name("getPageWiseGridMembers(confId:gridPageNumber:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetPinnedMembers *> *)getPinnedMembersConfId:(NSString *)confId __attribute__((swift_name("getPinnedMembers(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getPinnedMembersConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong *))mapper __attribute__((swift_name("getPinnedMembers(confId:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMeetingsMemberEntity *> *)getScreenShareConfId:(NSString *)confId __attribute__((swift_name("getScreenShare(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getScreenShareConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable))mapper __attribute__((swift_name("getScreenShare(confId:mapper:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getSecondaryAdminUserIdsConfId:(NSString *)confId __attribute__((swift_name("getSecondaryAdminUserIds(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetSingleUserTypeMeetingMember *> *)getSingleUserTypeMeetingMemberConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("getSingleUserTypeMeetingMember(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getSingleUserTypeMeetingMemberConfId:(NSString *)confId userId:(NSString *)userId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("getSingleUserTypeMeetingMember(confId:userId:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMemberRole *> *)getSingleUserTypeMeetingMemberRoleConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("getSingleUserTypeMeetingMemberRole(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getSortedUserIdsForGridConfId:(NSString *)confId __attribute__((swift_name("getSortedUserIdsForGrid(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreMeetingsMemberEntity *> *)getStageMembersConfId:(NSString *)confId speakerCount:(int64_t)speakerCount __attribute__((swift_name("getStageMembers(confId:speakerCount:)")));
- (MeetingsCoreRuntimeQuery<id> *)getStageMembersConfId:(NSString *)confId speakerCount:(int64_t)speakerCount mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, NSString * _Nullable, MeetingsCoreViewType *, MeetingsCoreMemberType *, MeetingsCoreMemberRole *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreBoolean *, MeetingsCoreLong *, MeetingsCoreLong *, MeetingsCoreLong *, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable))mapper __attribute__((swift_name("getStageMembers(confId:speakerCount:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetStreamIdsForGrid *> *)getStreamIdsForGridConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("getStreamIdsForGrid(confId:userIds:)")));
- (MeetingsCoreRuntimeQuery<id> *)getStreamIdsForGridConfId:(NSString *)confId userIds:(id)userIds mapper:(id (^)(NSString *, NSString * _Nullable))mapper __attribute__((swift_name("getStreamIdsForGrid(confId:userIds:mapper:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)getVideoStatusByIdConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("getVideoStatusById(confId:userId:)")));
- (void)insertOrIgnoreMeetingMemberPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq __attribute__((swift_name("insertOrIgnoreMeetingMember(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:)")));
- (void)insertOrReplaceMeetingMemberPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString *)confId userId:(NSString *)userId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking ringing:(BOOL)ringing addedTime:(int64_t)addedTime audioWeight:(int64_t)audioWeight stagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId gridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime pinnedSeq:(MeetingsCoreLong * _Nullable)pinnedSeq __attribute__((swift_name("insertOrReplaceMeetingMember(pkId:confId:userId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:ringing:addedTime:audioWeight:stagePosition:stageStreamId:gridStreamId:gridPageNumber:firstJoinedTime:joinedTime:pinnedSeq:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)isAssignPrimaryAdminMembersAvailableConfId:(NSString *)confId __attribute__((swift_name("isAssignPrimaryAdminMembersAvailable(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)isMeetingsMemberRingingConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("isMeetingsMemberRinging(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)isMemberAlreadyParticipantConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("isMemberAlreadyParticipant(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)isMemberUserViewTypeAvailableConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("isMemberUserViewTypeAvailable(confId:userId:)")));
- (void)resetGridPageDetailsConfId:(NSString *)confId excludedUserIds:(id)excludedUserIds __attribute__((swift_name("resetGridPageDetails(confId:excludedUserIds:)")));
- (void)resetSpeakingConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("resetSpeaking(confId:userId:)")));
- (void)resetStagePositionConfId:(NSString *)confId excludedUserIds:(id)excludedUserIds __attribute__((swift_name("resetStagePosition(confId:excludedUserIds:)")));
- (void)updateAudioWeightAndSpeakingConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("updateAudioWeightAndSpeaking(confId:userIds:)")));
- (void)updateCameraStatusVideoEnabled:(BOOL)videoEnabled confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateCameraStatus(videoEnabled:confId:userId:)")));
- (void)updateEnableAudioRestrictedStatusEnableAudioRestricted:(BOOL)enableAudioRestricted confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateEnableAudioRestrictedStatus(enableAudioRestricted:confId:userId:)")));
- (void)updateEnableAudioRestrictedStatusForAllEnableAudioRestricted:(BOOL)enableAudioRestricted confId:(NSString *)confId excludedUserIds:(id)excludedUserIds __attribute__((swift_name("updateEnableAudioRestrictedStatusForAll(enableAudioRestricted:confId:excludedUserIds:)")));
- (void)updateGridPageDetailsGridPageNumber:(MeetingsCoreLong * _Nullable)gridPageNumber gridStreamId:(NSString * _Nullable)gridStreamId confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateGridPageDetails(gridPageNumber:gridStreamId:confId:userId:)")));
- (void)updateMemberRoleRole:(MeetingsCoreMemberRole *)role confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateMemberRole(role:confId:userId:)")));
- (void)updateMemberTypeMemberType:(MeetingsCoreMemberType *)memberType confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateMemberType(memberType:confId:userId:)")));
- (void)updateMemberTypeMemberRoleAndJoinedTimesMemberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateMemberTypeMemberRoleAndJoinedTimes(memberType:role:firstJoinedTime:joinedTime:confId:userId:)")));
- (void)updateMemberTypeMicCamStatusRoleAndJoinedTimesMemberType:(MeetingsCoreMemberType *)memberType audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled role:(MeetingsCoreMemberRole *)role firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateMemberTypeMicCamStatusRoleAndJoinedTimes(memberType:audioEnabled:enableAudioRestricted:videoEnabled:role:firstJoinedTime:joinedTime:confId:userId:)")));
- (void)updateMicStatusAudioEnabled:(BOOL)audioEnabled confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateMicStatus(audioEnabled:confId:userId:)")));
- (void)updateNameAndMemberTypeMemberType:(MeetingsCoreMemberType *)memberType name:(NSString * _Nullable)name confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateNameAndMemberType(memberType:name:confId:userId:)")));
- (void)updateNameMemberTypeMemberRoleAndJoinedTimesMemberType:(MeetingsCoreMemberType *)memberType name:(NSString * _Nullable)name role:(MeetingsCoreMemberRole *)role firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateNameMemberTypeMemberRoleAndJoinedTimes(memberType:name:role:firstJoinedTime:joinedTime:confId:userId:)")));
- (void)updateNameMemberTypeMicCamStatusRoleAndJoinedTimesName:(NSString * _Nullable)name memberType:(MeetingsCoreMemberType *)memberType audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled role:(MeetingsCoreMemberRole *)role firstJoinedTime:(MeetingsCoreLong * _Nullable)firstJoinedTime joinedTime:(MeetingsCoreLong * _Nullable)joinedTime confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateNameMemberTypeMicCamStatusRoleAndJoinedTimes(name:memberType:audioEnabled:enableAudioRestricted:videoEnabled:role:firstJoinedTime:joinedTime:confId:userId:)")));
- (void)updateRingingAllStatusIsRinging:(BOOL)isRinging confId:(NSString *)confId excludedUserIds:(id)excludedUserIds __attribute__((swift_name("updateRingingAllStatus(isRinging:confId:excludedUserIds:)")));
- (void)updateRingingStatusIsRinging:(BOOL)isRinging confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateRingingStatus(isRinging:confId:userId:)")));
- (void)updateScreenShareStreamIdStreamId:(NSString * _Nullable)streamId confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateScreenShareStreamId(streamId:confId:userId:)")));
- (void)updateStageStreamIdsPositionStagePosition:(int64_t)stagePosition stageStreamId:(NSString * _Nullable)stageStreamId confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("updateStageStreamIdsPosition(stagePosition:stageStreamId:confId:userId:)")));
- (void)updateStopRingingAllStatusConfId:(NSString *)confId __attribute__((swift_name("updateStopRingingAllStatus(confId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingsMemberRingLogEntity")))
@interface MeetingsCoreMeetingsMemberRingLogEntity : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId ringing:(BOOL)ringing messageTime:(int64_t)messageTime __attribute__((swift_name("init(pkId:confId:userId:ringing:messageTime:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreMeetingsMemberRingLogEntity *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId ringing:(BOOL)ringing messageTime:(int64_t)messageTime __attribute__((swift_name("doCopy(pkId:confId:userId:ringing:messageTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) int64_t messageTime __attribute__((swift_name("messageTime")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingsMemberRingLogEntityQueries")))
@interface MeetingsCoreMeetingsMemberRingLogEntityQueries : MeetingsCoreRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)clearMeetingsMemberRingLogs __attribute__((swift_name("clearMeetingsMemberRingLogs()")));
- (void)insertOrIgnoreMeetingMemberRingLogPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString *)confId userId:(NSString *)userId ringing:(BOOL)ringing messageTime:(int64_t)messageTime __attribute__((swift_name("insertOrIgnoreMeetingMemberRingLog(pkId:confId:userId:ringing:messageTime:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)isValidRingLogEntryMessageTime:(int64_t)messageTime confId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("isValidRingLogEntry(messageTime:confId:userId:)")));
@end

__attribute__((swift_name("RTCPMeetingsDatabase")))
@protocol MeetingsCoreRTCPMeetingsDatabase <MeetingsCoreRuntimeTransacter>
@required
@property (readonly) MeetingsCoreMeetingsMemberEntityQueries *meetingsMemberEntityQueries __attribute__((swift_name("meetingsMemberEntityQueries")));
@property (readonly) MeetingsCoreMeetingsMemberRingLogEntityQueries *meetingsMemberRingLogEntityQueries __attribute__((swift_name("meetingsMemberRingLogEntityQueries")));
@property (readonly) MeetingsCoreSpeakRequestMemberEntityQueries *speakRequestMemberEntityQueries __attribute__((swift_name("speakRequestMemberEntityQueries")));
@property (readonly) MeetingsCoreSpotLightMemberEntityQueries *spotLightMemberEntityQueries __attribute__((swift_name("spotLightMemberEntityQueries")));
@property (readonly) MeetingsCoreWaitingRequestMemberEntityQueries *waitingRequestMemberEntityQueries __attribute__((swift_name("waitingRequestMemberEntityQueries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsDatabaseCompanion")))
@interface MeetingsCoreRTCPMeetingsDatabaseCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPMeetingsDatabaseCompanion *shared __attribute__((swift_name("shared")));
- (id<MeetingsCoreRTCPMeetingsDatabase>)invokeDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver MeetingsMemberEntityAdapter:(MeetingsCoreMeetingsMemberEntityAdapter *)MeetingsMemberEntityAdapter WaitingRequestMemberEntityAdapter:(MeetingsCoreWaitingRequestMemberEntityAdapter *)WaitingRequestMemberEntityAdapter __attribute__((swift_name("invoke(driver:MeetingsMemberEntityAdapter:WaitingRequestMemberEntityAdapter:)")));
@property (readonly) id<MeetingsCoreRuntimeSqlSchema> Schema __attribute__((swift_name("Schema")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeakRequestMemberEntity")))
@interface MeetingsCoreSpeakRequestMemberEntity : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime __attribute__((swift_name("init(pkId:confId:userId:addedTime:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreSpeakRequestMemberEntity *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime __attribute__((swift_name("doCopy(pkId:confId:userId:addedTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpeakRequestMemberEntityQueries")))
@interface MeetingsCoreSpeakRequestMemberEntityQueries : MeetingsCoreRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)clearSpeakRequestMembers __attribute__((swift_name("clearSpeakRequestMembers()")));
- (void)deleteSpeakRequestConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("deleteSpeakRequest(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)getSpeakRequestMembersCountConfId:(NSString *)confId __attribute__((swift_name("getSpeakRequestMembersCount(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetSpeakRequestMembersList *> *)getSpeakRequestMembersListConfId:(NSString *)confId __attribute__((swift_name("getSpeakRequestMembersList(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getSpeakRequestMembersListConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, MeetingsCoreLong *, NSString * _Nullable))mapper __attribute__((swift_name("getSpeakRequestMembersList(confId:mapper:)")));
- (void)insertOrReplaceSpeakRequestMemberPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime __attribute__((swift_name("insertOrReplaceSpeakRequestMember(pkId:confId:userId:addedTime:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)isMemberRequestedToSpeakConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("isMemberRequestedToSpeak(confId:userId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpotLightMemberEntity")))
@interface MeetingsCoreSpotLightMemberEntity : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime __attribute__((swift_name("init(pkId:confId:userId:addedTime:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreSpotLightMemberEntity *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime __attribute__((swift_name("doCopy(pkId:confId:userId:addedTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SpotLightMemberEntityQueries")))
@interface MeetingsCoreSpotLightMemberEntityQueries : MeetingsCoreRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver MeetingsMemberEntityAdapter:(MeetingsCoreMeetingsMemberEntityAdapter *)MeetingsMemberEntityAdapter __attribute__((swift_name("init(driver:MeetingsMemberEntityAdapter:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)clearSpotLightMembers __attribute__((swift_name("clearSpotLightMembers()")));
- (void)deleteAllSpotLightMembersConfId:(NSString *)confId __attribute__((swift_name("deleteAllSpotLightMembers(confId:)")));
- (void)deleteSpotLightMemberConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("deleteSpotLightMember(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetSpotLightMembersList *> *)getSpotLightMembersListConfId:(NSString *)confId __attribute__((swift_name("getSpotLightMembersList(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getSpotLightMembersListConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong * _Nullable, NSString * _Nullable, NSString * _Nullable, NSString * _Nullable, MeetingsCoreViewType * _Nullable, MeetingsCoreMemberType * _Nullable, MeetingsCoreMemberRole * _Nullable, MeetingsCoreBoolean * _Nullable, MeetingsCoreBoolean * _Nullable, MeetingsCoreBoolean * _Nullable, MeetingsCoreBoolean * _Nullable, MeetingsCoreBoolean * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString * _Nullable, NSString * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, MeetingsCoreLong * _Nullable, NSString *))mapper __attribute__((swift_name("getSpotLightMembersList(confId:mapper:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getSpotLightMembersUserIdListConfId:(NSString *)confId __attribute__((swift_name("getSpotLightMembersUserIdList(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)getSpotlightMembersCountConfId:(NSString *)confId __attribute__((swift_name("getSpotlightMembersCount(confId:)")));
- (void)insertOrReplaceSpotlightMemberPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString *)confId userId:(NSString *)userId addedTime:(int64_t)addedTime __attribute__((swift_name("insertOrReplaceSpotlightMember(pkId:confId:userId:addedTime:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreBoolean *> *)isSpotLightMembersAvailableConfId:(NSString *)confId __attribute__((swift_name("isSpotLightMembersAvailable(confId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WaitingRequestMemberEntity")))
@interface MeetingsCoreWaitingRequestMemberEntity : MeetingsCoreBase
- (instancetype)initWithPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId requestType:(MeetingsCoreRequestType *)requestType addedTime:(int64_t)addedTime __attribute__((swift_name("init(pkId:confId:userId:requestType:addedTime:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreWaitingRequestMemberEntity *)doCopyPkId:(int64_t)pkId confId:(NSString *)confId userId:(NSString *)userId requestType:(MeetingsCoreRequestType *)requestType addedTime:(int64_t)addedTime __attribute__((swift_name("doCopy(pkId:confId:userId:requestType:addedTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t addedTime __attribute__((swift_name("addedTime")));
@property (readonly) NSString *confId __attribute__((swift_name("confId")));
@property (readonly) int64_t pkId __attribute__((swift_name("pkId")));
@property (readonly) MeetingsCoreRequestType *requestType __attribute__((swift_name("requestType")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WaitingRequestMemberEntity.Adapter")))
@interface MeetingsCoreWaitingRequestMemberEntityAdapter : MeetingsCoreBase
- (instancetype)initWithRequestTypeAdapter:(id<MeetingsCoreRuntimeColumnAdapter>)requestTypeAdapter __attribute__((swift_name("init(requestTypeAdapter:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<MeetingsCoreRuntimeColumnAdapter> requestTypeAdapter __attribute__((swift_name("requestTypeAdapter")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WaitingRequestMemberEntityQueries")))
@interface MeetingsCoreWaitingRequestMemberEntityQueries : MeetingsCoreRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver WaitingRequestMemberEntityAdapter:(MeetingsCoreWaitingRequestMemberEntityAdapter *)WaitingRequestMemberEntityAdapter __attribute__((swift_name("init(driver:WaitingRequestMemberEntityAdapter:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)changeAllWaitingRequestAsApprovedConfId:(NSString *)confId __attribute__((swift_name("changeAllWaitingRequestAsApproved(confId:)")));
- (void)changeAllWaitingRequestAsRejectedConfId:(NSString *)confId __attribute__((swift_name("changeAllWaitingRequestAsRejected(confId:)")));
- (void)changeRequestAsApprovedConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("changeRequestAsApproved(confId:userId:)")));
- (void)changeRequestAsRejectedConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("changeRequestAsRejected(confId:userId:)")));
- (void)changeRequestsAsApprovedConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("changeRequestsAsApproved(confId:userIds:)")));
- (void)changeRequestsAsRejectedConfId:(NSString *)confId userIds:(id)userIds __attribute__((swift_name("changeRequestsAsRejected(confId:userIds:)")));
- (void)clearWaitingRequestMembers __attribute__((swift_name("clearWaitingRequestMembers()")));
- (void)deleteWaitingRequestsConfId:(NSString *)confId userId:(NSString *)userId __attribute__((swift_name("deleteWaitingRequests(confId:userId:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getRequestMemberAlreadyApprovedOrInWaitingRoomUserIdListConfId:(NSString *)confId __attribute__((swift_name("getRequestMemberAlreadyApprovedOrInWaitingRoomUserIdList(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreLong *> *)getWaitingRequestMembersCountConfId:(NSString *)confId __attribute__((swift_name("getWaitingRequestMembersCount(confId:)")));
- (MeetingsCoreRuntimeQuery<MeetingsCoreGetWaitingRequestMembersList *> *)getWaitingRequestMembersListConfId:(NSString *)confId __attribute__((swift_name("getWaitingRequestMembersList(confId:)")));
- (MeetingsCoreRuntimeQuery<id> *)getWaitingRequestMembersListConfId:(NSString *)confId mapper:(id (^)(MeetingsCoreLong *, NSString *, NSString *, MeetingsCoreRequestType *, MeetingsCoreLong *, NSString * _Nullable))mapper __attribute__((swift_name("getWaitingRequestMembersList(confId:mapper:)")));
- (MeetingsCoreRuntimeQuery<NSString *> *)getWaitingRequestMembersUserIdListConfId:(NSString *)confId __attribute__((swift_name("getWaitingRequestMembersUserIdList(confId:)")));
- (void)insertOrReplaceWaitingRequestMemberPkId:(MeetingsCoreLong * _Nullable)pkId confId:(NSString *)confId userId:(NSString *)userId requestType:(MeetingsCoreRequestType *)requestType addedTime:(int64_t)addedTime __attribute__((swift_name("insertOrReplaceWaitingRequestMember(pkId:confId:userId:requestType:addedTime:)")));
@end

__attribute__((swift_name("AudioSource")))
@interface MeetingsCoreAudioSource : MeetingsCoreBase
- (BOOL)isEqualToOther:(id _Nullable)other __attribute__((swift_name("isEqualTo(other:)")));
@property (readonly) BOOL isBluetoothConnected __attribute__((swift_name("isBluetoothConnected")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioSource.BLUETOOTH")))
@interface MeetingsCoreAudioSourceBLUETOOTH : MeetingsCoreAudioSource
- (instancetype)initWithDeviceName:(NSString *)deviceName isConnected:(BOOL)isConnected __attribute__((swift_name("init(deviceName:isConnected:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreAudioSourceBLUETOOTH *)doCopyDeviceName:(NSString *)deviceName isConnected:(BOOL)isConnected __attribute__((swift_name("doCopy(deviceName:isConnected:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *deviceName __attribute__((swift_name("deviceName")));
@property (readonly) BOOL isConnected __attribute__((swift_name("isConnected")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioSource.EARPIECE")))
@interface MeetingsCoreAudioSourceEARPIECE : MeetingsCoreAudioSource
- (instancetype)initWithBluetoothDeviceName:(NSString *)bluetoothDeviceName bluetoothConnected:(BOOL)bluetoothConnected __attribute__((swift_name("init(bluetoothDeviceName:bluetoothConnected:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreAudioSourceEARPIECE *)doCopyBluetoothDeviceName:(NSString *)bluetoothDeviceName bluetoothConnected:(BOOL)bluetoothConnected __attribute__((swift_name("doCopy(bluetoothDeviceName:bluetoothConnected:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioSource.NONE")))
@interface MeetingsCoreAudioSourceNONE : MeetingsCoreAudioSource
- (instancetype)initWithBluetoothDeviceName:(NSString *)bluetoothDeviceName bluetoothConnected:(BOOL)bluetoothConnected __attribute__((swift_name("init(bluetoothDeviceName:bluetoothConnected:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreAudioSourceNONE *)doCopyBluetoothDeviceName:(NSString *)bluetoothDeviceName bluetoothConnected:(BOOL)bluetoothConnected __attribute__((swift_name("doCopy(bluetoothDeviceName:bluetoothConnected:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioSource.SPEAKER")))
@interface MeetingsCoreAudioSourceSPEAKER : MeetingsCoreAudioSource
- (instancetype)initWithBluetoothDeviceName:(NSString *)bluetoothDeviceName bluetoothConnected:(BOOL)bluetoothConnected __attribute__((swift_name("init(bluetoothDeviceName:bluetoothConnected:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreAudioSourceSPEAKER *)doCopyBluetoothDeviceName:(NSString *)bluetoothDeviceName bluetoothConnected:(BOOL)bluetoothConnected __attribute__((swift_name("doCopy(bluetoothDeviceName:bluetoothConnected:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RTCPAudioManager")))
@interface MeetingsCoreRTCPAudioManager : MeetingsCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MeetingsCoreRTCPAudioManagerCompanion *companion __attribute__((swift_name("companion")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreAudioSource *> *)getAudioSource __attribute__((swift_name("getAudioSource()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAudioSourceObservable __attribute__((swift_name("getAudioSourceObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)updateAudioSourceAudioSource:(MeetingsCoreAudioSource *)audioSource __attribute__((swift_name("updateAudioSource(audioSource:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPAudioManager.Companion")))
@interface MeetingsCoreRTCPAudioManagerCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPAudioManagerCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreRTCPAudioManager *)instance __attribute__((swift_name("instance()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPAudioManagerImpl")))
@interface MeetingsCoreRTCPAudioManagerImpl : MeetingsCoreRTCPAudioManager
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreAudioSource *> *)getAudioSource __attribute__((swift_name("getAudioSource()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAudioSourceObservable __attribute__((swift_name("getAudioSourceObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)updateAudioSourceAudioSource:(MeetingsCoreAudioSource *)audioSource __attribute__((swift_name("updateAudioSource(audioSource:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface MeetingsCoreKotlinThrowable : MeetingsCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (MeetingsCoreKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCoreKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface MeetingsCoreKotlinException : MeetingsCoreKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthException")))
@interface MeetingsCoreAuthException : MeetingsCoreKotlinException
- (instancetype)initWithMessage:(NSString * _Nullable)message t:(MeetingsCoreKotlinThrowable * _Nullable)t __attribute__((swift_name("init(message:t:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("ClientAccessToken")))
@protocol MeetingsCoreClientAccessToken
@required
- (void)forceUpdateUserId:(NSString * _Nullable)userId __attribute__((swift_name("forceUpdate(userId:)")));
- (NSString *)getUserId:(NSString * _Nullable)userId __attribute__((swift_name("get(userId:)")));
- (void)invalidateUserId:(NSString * _Nullable)userId __attribute__((swift_name("invalidate(userId:)")));
- (BOOL)isAvailableUserId:(NSString * _Nullable)userId __attribute__((swift_name("isAvailable(userId:)")));
- (void)setUserId:(NSString *)userId accessToken:(NSString *)accessToken refreshToken:(NSString *)refreshToken expiresIn:(MeetingsCoreLong * _Nullable)expiresIn callKey:(NSString *)callKey clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret redirectUri:(NSString *)redirectUri grantType:(NSString *)grantType onFetchTokenFailed:(void (^ _Nullable)(MeetingsCoreAuthException *))onFetchTokenFailed refreshTokenAPI:(id<MeetingsCoreKotlinSuspendFunction1>)refreshTokenAPI __attribute__((swift_name("set(userId:accessToken:refreshToken:expiresIn:callKey:clientId:clientSecret:redirectUri:grantType:onFetchTokenFailed:refreshTokenAPI:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((swift_name("ClientAccessTokenResponse")))
@interface MeetingsCoreClientAccessTokenResponse : MeetingsCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MeetingsCoreClientAccessTokenResponseCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable clientAccessToken __attribute__((swift_name("clientAccessToken")));
@property (readonly) MeetingsCoreLong * _Nullable expiresIn __attribute__((swift_name("expiresIn")));
@property (readonly) NSString * _Nullable refreshToken __attribute__((swift_name("refreshToken")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ClientAccessTokenResponse.Companion")))
@interface MeetingsCoreClientAccessTokenResponseCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreClientAccessTokenResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MeetingsCoreKotlinArray<id<MeetingsCoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end

__attribute__((swift_name("Ktor_client_loggingLogger")))
@protocol MeetingsCoreKtor_client_loggingLogger
@required
- (void)logMessage:(NSString *)message __attribute__((swift_name("log(message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HTTPWMSLogger")))
@interface MeetingsCoreHTTPWMSLogger : MeetingsCoreBase <MeetingsCoreKtor_client_loggingLogger>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)hTTPWMSLogger __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreHTTPWMSLogger *shared __attribute__((swift_name("shared")));
- (void)logMessage:(NSString *)message __attribute__((swift_name("log(message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpLogger")))
@interface MeetingsCoreHttpLogger : MeetingsCoreBase <MeetingsCoreKtor_client_loggingLogger>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)httpLogger __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreHttpLogger *shared __attribute__((swift_name("shared")));
- (void)logMessage:(NSString *)message __attribute__((swift_name("log(message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Log")))
@interface MeetingsCoreLog : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)log __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreLog *shared __attribute__((swift_name("shared")));
- (void)dTag:(NSString *)tag message:(NSString * _Nullable)message tr:(MeetingsCoreKotlinThrowable * _Nullable)tr __attribute__((swift_name("d(tag:message:tr:)")));
- (void)eTag:(NSString *)tag message:(NSString * _Nullable)message tr:(MeetingsCoreKotlinThrowable * _Nullable)tr __attribute__((swift_name("e(tag:message:tr:)")));
- (void)iTag:(NSString *)tag message:(NSString * _Nullable)message tr:(MeetingsCoreKotlinThrowable * _Nullable)tr __attribute__((swift_name("i(tag:message:tr:)")));
@end

__attribute__((swift_name("Rtcp_coreRTCPCoreLogger")))
@protocol MeetingsCoreRtcp_coreRTCPCoreLogger
@required
- (void)logDTag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logD(tag:message:)")));
- (void)logETag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logE(tag:message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPCoreLogger")))
@interface MeetingsCoreRTCPCoreLogger : MeetingsCoreBase <MeetingsCoreRtcp_coreRTCPCoreLogger>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)logDTag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logD(tag:message:)")));
- (void)logETag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logE(tag:message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingDebugLogging")))
@interface MeetingsCoreRTCPMeetingDebugLogging : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)rTCPMeetingDebugLogging __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPMeetingDebugLogging *shared __attribute__((swift_name("shared")));
- (void)logDTag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logD(tag:message:)")));
- (void)logETag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logE(tag:message:)")));
- (void)logITag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logI(tag:message:)")));
- (void)setLoggerLogger:(id<MeetingsCoreRTCPMeetingsDebugLogger>)logger __attribute__((swift_name("setLogger(logger:)")));
@end

__attribute__((swift_name("RTCPMeetingsClientLogger")))
@protocol MeetingsCoreRTCPMeetingsClientLogger
@required
- (void)logDTag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logD(tag:message:)")));
- (void)logETag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logE(tag:message:)")));
@end

__attribute__((swift_name("RTCPMeetingsDebugLogger")))
@protocol MeetingsCoreRTCPMeetingsDebugLogger
@required
- (void)logDTag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logD(tag:message:)")));
- (void)logETag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logE(tag:message:)")));
- (void)logITag:(NSString * _Nullable)tag message:(id)message __attribute__((swift_name("logI(tag:message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPCustomVideoCapturerManager")))
@interface MeetingsCoreRTCPCustomVideoCapturerManager : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)rTCPCustomVideoCapturerManager __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPCustomVideoCapturerManager *shared __attribute__((swift_name("shared")));
- (void)destroyCustomVideoSource __attribute__((swift_name("destroyCustomVideoSource()")));
- (RTCVideoSource *)getVideoSource __attribute__((swift_name("getVideoSource()")));
- (RTCVideoSource *)doInitCustomVideoSource __attribute__((swift_name("doInitCustomVideoSource()")));
@end

__attribute__((swift_name("RTCPMeetingsClient")))
@interface MeetingsCoreRTCPMeetingsClient : MeetingsCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MeetingsCoreRTCPMeetingsClientCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)approveAllJoinRequestWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("approveAllJoinRequest(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)approveJoinRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("approveJoinRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)approveSpeakRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("approveSpeakRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)askEnableAudioAllWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("askEnableAudioAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)askEnableUserAudioUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("askEnableUserAudio(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignPrimaryAdminUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignPrimaryAdmin(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignSecondaryAdminUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignSecondaryAdmin(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bringToSpotlightUserIds:(NSArray<NSString *> *)userIds completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("bringToSpotlight(userIds:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelRequestToSpeakWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelRequestToSpeak(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelRingAllWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelRingAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelRingUserUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelRingUser(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeMeetingSessionWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("closeMeetingSession(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)configureOtherSpeakersVisibilityInSpotlightShowOtherSpeakers:(BOOL)showOtherSpeakers completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("configureOtherSpeakersVisibilityInSpotlight(showOtherSpeakers:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createAudioInputShouldInitAudioManager:(BOOL)shouldInitAudioManager forceInitAudioManager:(BOOL)forceInitAudioManager completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createAudioInput(shouldInitAudioManager:forceInitAudioManager:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createVideoInputVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingVideo *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createVideoInput(videoCaptureSpec:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableAudioAllRestrictEnableAudio:(MeetingsCoreBoolean * _Nullable)restrictEnableAudio completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("disableAudioAll(restrictEnableAudio:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableSpotlightWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("disableSpotlight(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableUserAudioUserId:(NSString *)userId restrictEnableAudio:(MeetingsCoreBoolean * _Nullable)restrictEnableAudio completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("disableUserAudio(userId:restrictEnableAudio:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissAssignedAsPrimaryAdminNotifierState __attribute__((swift_name("dismissAssignedAsPrimaryAdminNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissAudioEnabledDisabledNotifierState __attribute__((swift_name("dismissAudioEnabledDisabledNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissEnableAudioRestrictedNotifierState __attribute__((swift_name("dismissEnableAudioRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissEnableVideoRestrictedNotifierState __attribute__((swift_name("dismissEnableVideoRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissExpiryBannerNotifierState __attribute__((swift_name("dismissExpiryBannerNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissRecordingNotifierState __attribute__((swift_name("dismissRecordingNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissRemovedMemberNotifierState __attribute__((swift_name("dismissRemovedMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissSecondaryAdminAssignedRemovedNotifierState __attribute__((swift_name("dismissSecondaryAdminAssignedRemovedNotifierState()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)endMeetingAssignPrimaryAdminId:(NSString * _Nullable)assignPrimaryAdminId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("endMeeting(assignPrimaryAdminId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flipCameraWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreCameraFace *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("flipCamera(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getActiveSpeakingMembers __attribute__((swift_name("getActiveSpeakingMembers()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllAudioDisabledStatus __attribute__((swift_name("getAllAudioDisabledStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllJoinRequest __attribute__((swift_name("getAllJoinRequest()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllJoinRequestCount __attribute__((swift_name("getAllJoinRequestCount()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllSpeakRequest __attribute__((swift_name("getAllSpeakRequest()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllSpeakRequestCount __attribute__((swift_name("getAllSpeakRequestCount()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAssignPrimaryAdminMembersList __attribute__((swift_name("getAssignPrimaryAdminMembersList()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAudioStatus __attribute__((swift_name("getAudioStatus()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCurrentMemberWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingsMember *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCurrentMember(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getCurrentMemberObservable __attribute__((swift_name("getCurrentMemberObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getCurrentMemberRoleObservable __attribute__((swift_name("getCurrentMemberRoleObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getEnableAudioRestrictedAllStatus __attribute__((swift_name("getEnableAudioRestrictedAllStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getEnableAudioRestrictedMemberIds __attribute__((swift_name("getEnableAudioRestrictedMemberIds()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getEnableAudioRestrictedStatus __attribute__((swift_name("getEnableAudioRestrictedStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getGridMembers __attribute__((swift_name("getGridMembers()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsAudioDownStreamReconnectingState __attribute__((swift_name("getIsAudioDownStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsAudioUpStreamReconnectingState __attribute__((swift_name("getIsAudioUpStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsDataChannelReconnectingState __attribute__((swift_name("getIsDataChannelReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsMeetingEndedState __attribute__((swift_name("getIsMeetingEndedState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsNetworkAvailableState __attribute__((swift_name("getIsNetworkAvailableState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsRecordingState __attribute__((swift_name("getIsRecordingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsRingingAllState __attribute__((swift_name("getIsRingingAllState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsScreenShareDownStreamReconnectingState __attribute__((swift_name("getIsScreenShareDownStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsScreenShareUpStreamReconnectingState __attribute__((swift_name("getIsScreenShareUpStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsVideoDownStreamReconnectingState __attribute__((swift_name("getIsVideoDownStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsVideoUpStreamReconnectingState __attribute__((swift_name("getIsVideoUpStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getJoinedMemberNotifierState __attribute__((swift_name("getJoinedMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getLeftMemberNotifierState __attribute__((swift_name("getLeftMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMediaServerReachabilityReport __attribute__((swift_name("getMediaServerReachabilityReport()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingLayout __attribute__((swift_name("getMeetingLayout()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingMembersSearchQuery:(NSString *)searchQuery excludingStageMembers:(BOOL)excludingStageMembers __attribute__((swift_name("getMeetingMembers(searchQuery:excludingStageMembers:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingStartTime __attribute__((swift_name("getMeetingStartTime()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getMeetingStateWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingState *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getMeetingState(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingTitle __attribute__((swift_name("getMeetingTitle()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingsMemberCountExcludingMemberRoleNone:(BOOL)excludingMemberRoleNone __attribute__((swift_name("getMeetingsMemberCount(excludingMemberRoleNone:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getPrimaryAdminNameObservable __attribute__((swift_name("getPrimaryAdminNameObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingsConfigurations *> *)getRTCPMeetingsConfigurations __attribute__((swift_name("getRTCPMeetingsConfigurations()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getRecordingNotifierState __attribute__((swift_name("getRecordingNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getRemovedMemberNotifierState __attribute__((swift_name("getRemovedMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getScreenShare __attribute__((swift_name("getScreenShare()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowAssignedAsPrimaryAdminNotifierState __attribute__((swift_name("getShowAssignedAsPrimaryAdminNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowAudioEnabledDisabledNotifierState __attribute__((swift_name("getShowAudioEnabledDisabledNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowEnableAudioRestrictedNotifierState __attribute__((swift_name("getShowEnableAudioRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowEnableVideoRestrictedNotifierState __attribute__((swift_name("getShowEnableVideoRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowLimitExpiryBannerNotifierState __attribute__((swift_name("getShowLimitExpiryBannerNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowSecondaryAdminAssignedRemovedNotifierState __attribute__((swift_name("getShowSecondaryAdminAssignedRemovedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getSpotLightEnabledState __attribute__((swift_name("getSpotLightEnabledState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getSpotlightMemberCount __attribute__((swift_name("getSpotlightMemberCount()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getStageMembers __attribute__((swift_name("getStageMembers()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getVideoStatus __attribute__((swift_name("getVideoStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getWaitingRoomRequestStatus __attribute__((swift_name("getWaitingRoomRequestStatus()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)doInitMeetingSessionClientOtp:(NSString *)clientOtp callKey:(NSString *)callKey rtcpUserId:(NSString *)rtcpUserId authorization:(NSString *)authorization rtcpMeetingsRemoteConfigs:(MeetingsCoreRTCPMeetingsRemoteConfigs *)rtcpMeetingsRemoteConfigs rtcpWMSConfiguration:(MeetingsCoreRTCPWMSConfiguration * _Nullable)rtcpWMSConfiguration completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("doInitMeetingSession(clientOtp:callKey:rtcpUserId:authorization:rtcpMeetingsRemoteConfigs:rtcpWMSConfiguration:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isAllMeetingParticipantsAudioDisabled __attribute__((swift_name("isAllMeetingParticipantsAudioDisabled()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isAllMeetingParticipantsAudioEnabled __attribute__((swift_name("isAllMeetingParticipantsAudioEnabled()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isAssignPrimaryAdminMembersAvailable __attribute__((swift_name("isAssignPrimaryAdminMembersAvailable()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isMeetingConnectionEstablished __attribute__((swift_name("isMeetingConnectionEstablished()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isMemberRequestedToSpeakUserId:(NSString *)userId __attribute__((swift_name("isMemberRequestedToSpeak(userId:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isScreenSharingInProgress __attribute__((swift_name("isScreenSharingInProgress()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinMeetingUserDisplayName:(NSString * _Nullable)userDisplayName completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("joinMeeting(userDisplayName:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)otherSpeakersVisibilityRestrictedInSpotlight __attribute__((swift_name("otherSpeakersVisibilityRestrictedInSpotlight()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)rejectAllJoinRequestWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("rejectAllJoinRequest(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)rejectJoinRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("rejectJoinRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)rejectSpeakRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("rejectSpeakRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeFromSpotlightUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("removeFromSpotlight(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeSecondaryAdminUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("removeSecondaryAdmin(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)replaceAudioInputForceInitAudioManager:(BOOL)forceInitAudioManager completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("replaceAudioInput(forceInitAudioManager:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)replaceVideoInputVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("replaceVideoInput(videoCaptureSpec:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestToJoinMeetingUserDisplayName:(NSString * _Nullable)userDisplayName completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("requestToJoinMeeting(userDisplayName:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestToSpeakWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("requestToSpeak(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)resizeScreenShareContentVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec __attribute__((swift_name("resizeScreenShareContent(videoCaptureSpec:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)restrictEnableAudioWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("restrictEnableAudio(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)ringAllWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("ringAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)ringUserUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("ringUser(userId:completionHandler:)")));
- (void)setOnGetDisplayNameListenerGetUserDisplayNames:(id<MeetingsCoreKotlinSuspendFunction1>)getUserDisplayNames __attribute__((swift_name("setOnGetDisplayNameListener(getUserDisplayNames:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startMeetingMeetingTitle:(NSString *)meetingTitle userDisplayName:(NSString * _Nullable)userDisplayName completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startMeeting(meetingTitle:userDisplayName:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startScreenShareVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startScreenShare(videoCaptureSpec:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)stopScreenShareWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("stopScreenShare(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)subscribeVideosUserIds:(NSArray<NSString *> *)userIds completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("subscribeVideos(userIds:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)unRestrictEnableAudioWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("unRestrictEnableAudio(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAudioStatusEnable:(BOOL)enable completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAudioStatus(enable:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)updateOutputAudioStatusEnable:(BOOL)enable __attribute__((swift_name("updateOutputAudioStatus(enable:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateVideoStatusEnable:(BOOL)enable completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateVideoStatus(enable:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClient.Companion")))
@interface MeetingsCoreRTCPMeetingsClientCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPMeetingsClientCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreRTCPMeetingsClient *)instance __attribute__((swift_name("instance()")));
- (void)setRTCPMeetingsClientLoggerRtcpMeetingsClientLogger:(id<MeetingsCoreRTCPMeetingsClientLogger>)rtcpMeetingsClientLogger __attribute__((swift_name("setRTCPMeetingsClientLogger(rtcpMeetingsClientLogger:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClientImpl")))
@interface MeetingsCoreRTCPMeetingsClientImpl : MeetingsCoreRTCPMeetingsClient
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)approveAllJoinRequestWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("approveAllJoinRequest(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)approveJoinRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("approveJoinRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)approveSpeakRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("approveSpeakRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)askEnableAudioAllWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("askEnableAudioAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)askEnableUserAudioUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("askEnableUserAudio(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignPrimaryAdminUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignPrimaryAdmin(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)assignSecondaryAdminUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("assignSecondaryAdmin(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bringToSpotlightUserIds:(NSArray<NSString *> *)userIds completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("bringToSpotlight(userIds:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelRequestToSpeakWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelRequestToSpeak(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelRingAllWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelRingAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelRingUserUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelRingUser(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeMeetingSessionWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("closeMeetingSession(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)configureOtherSpeakersVisibilityInSpotlightShowOtherSpeakers:(BOOL)showOtherSpeakers completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("configureOtherSpeakersVisibilityInSpotlight(showOtherSpeakers:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createAudioInputShouldInitAudioManager:(BOOL)shouldInitAudioManager forceInitAudioManager:(BOOL)forceInitAudioManager completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createAudioInput(shouldInitAudioManager:forceInitAudioManager:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createVideoInputVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingVideo *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createVideoInput(videoCaptureSpec:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableAudioAllRestrictEnableAudio:(MeetingsCoreBoolean * _Nullable)restrictEnableAudio completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("disableAudioAll(restrictEnableAudio:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableSpotlightWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("disableSpotlight(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableUserAudioUserId:(NSString *)userId restrictEnableAudio:(MeetingsCoreBoolean * _Nullable)restrictEnableAudio completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("disableUserAudio(userId:restrictEnableAudio:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissAssignedAsPrimaryAdminNotifierState __attribute__((swift_name("dismissAssignedAsPrimaryAdminNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissAudioEnabledDisabledNotifierState __attribute__((swift_name("dismissAudioEnabledDisabledNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissEnableAudioRestrictedNotifierState __attribute__((swift_name("dismissEnableAudioRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissEnableVideoRestrictedNotifierState __attribute__((swift_name("dismissEnableVideoRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissExpiryBannerNotifierState __attribute__((swift_name("dismissExpiryBannerNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissRecordingNotifierState __attribute__((swift_name("dismissRecordingNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissRemovedMemberNotifierState __attribute__((swift_name("dismissRemovedMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)dismissSecondaryAdminAssignedRemovedNotifierState __attribute__((swift_name("dismissSecondaryAdminAssignedRemovedNotifierState()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)endMeetingAssignPrimaryAdminId:(NSString * _Nullable)assignPrimaryAdminId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("endMeeting(assignPrimaryAdminId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flipCameraWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreCameraFace *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("flipCamera(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getActiveSpeakingMembers __attribute__((swift_name("getActiveSpeakingMembers()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllAudioDisabledStatus __attribute__((swift_name("getAllAudioDisabledStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllJoinRequest __attribute__((swift_name("getAllJoinRequest()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllJoinRequestCount __attribute__((swift_name("getAllJoinRequestCount()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllSpeakRequest __attribute__((swift_name("getAllSpeakRequest()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAllSpeakRequestCount __attribute__((swift_name("getAllSpeakRequestCount()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAssignPrimaryAdminMembersList __attribute__((swift_name("getAssignPrimaryAdminMembersList()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getAudioStatus __attribute__((swift_name("getAudioStatus()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCurrentMemberWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingsMember *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCurrentMember(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getCurrentMemberObservable __attribute__((swift_name("getCurrentMemberObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getCurrentMemberRoleObservable __attribute__((swift_name("getCurrentMemberRoleObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getEnableAudioRestrictedAllStatus __attribute__((swift_name("getEnableAudioRestrictedAllStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getEnableAudioRestrictedMemberIds __attribute__((swift_name("getEnableAudioRestrictedMemberIds()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getEnableAudioRestrictedStatus __attribute__((swift_name("getEnableAudioRestrictedStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getGridMembers __attribute__((swift_name("getGridMembers()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsAudioDownStreamReconnectingState __attribute__((swift_name("getIsAudioDownStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsAudioUpStreamReconnectingState __attribute__((swift_name("getIsAudioUpStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsDataChannelReconnectingState __attribute__((swift_name("getIsDataChannelReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsMeetingEndedState __attribute__((swift_name("getIsMeetingEndedState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsNetworkAvailableState __attribute__((swift_name("getIsNetworkAvailableState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsRecordingState __attribute__((swift_name("getIsRecordingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsRingingAllState __attribute__((swift_name("getIsRingingAllState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsScreenShareDownStreamReconnectingState __attribute__((swift_name("getIsScreenShareDownStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsScreenShareUpStreamReconnectingState __attribute__((swift_name("getIsScreenShareUpStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsVideoDownStreamReconnectingState __attribute__((swift_name("getIsVideoDownStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getIsVideoUpStreamReconnectingState __attribute__((swift_name("getIsVideoUpStreamReconnectingState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getJoinedMemberNotifierState __attribute__((swift_name("getJoinedMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getLeftMemberNotifierState __attribute__((swift_name("getLeftMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMediaServerReachabilityReport __attribute__((swift_name("getMediaServerReachabilityReport()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingLayout __attribute__((swift_name("getMeetingLayout()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingMembersSearchQuery:(NSString *)searchQuery excludingStageMembers:(BOOL)excludingStageMembers __attribute__((swift_name("getMeetingMembers(searchQuery:excludingStageMembers:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingStartTime __attribute__((swift_name("getMeetingStartTime()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getMeetingStateWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingState *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getMeetingState(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingTitle __attribute__((swift_name("getMeetingTitle()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getMeetingsMemberCountExcludingMemberRoleNone:(BOOL)excludingMemberRoleNone __attribute__((swift_name("getMeetingsMemberCount(excludingMemberRoleNone:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getPrimaryAdminNameObservable __attribute__((swift_name("getPrimaryAdminNameObservable()")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreRTCPMeetingsConfigurations *> *)getRTCPMeetingsConfigurations __attribute__((swift_name("getRTCPMeetingsConfigurations()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getRecordingNotifierState __attribute__((swift_name("getRecordingNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getRemovedMemberNotifierState __attribute__((swift_name("getRemovedMemberNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getScreenShare __attribute__((swift_name("getScreenShare()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowAssignedAsPrimaryAdminNotifierState __attribute__((swift_name("getShowAssignedAsPrimaryAdminNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowAudioEnabledDisabledNotifierState __attribute__((swift_name("getShowAudioEnabledDisabledNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowEnableAudioRestrictedNotifierState __attribute__((swift_name("getShowEnableAudioRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowEnableVideoRestrictedNotifierState __attribute__((swift_name("getShowEnableVideoRestrictedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowLimitExpiryBannerNotifierState __attribute__((swift_name("getShowLimitExpiryBannerNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getShowSecondaryAdminAssignedRemovedNotifierState __attribute__((swift_name("getShowSecondaryAdminAssignedRemovedNotifierState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getSpotLightEnabledState __attribute__((swift_name("getSpotLightEnabledState()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getSpotlightMemberCount __attribute__((swift_name("getSpotlightMemberCount()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getStageMembers __attribute__((swift_name("getStageMembers()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getVideoStatus __attribute__((swift_name("getVideoStatus()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)getWaitingRoomRequestStatus __attribute__((swift_name("getWaitingRoomRequestStatus()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)doInitMeetingSessionClientOtp:(NSString *)clientOtp callKey:(NSString *)callKey rtcpUserId:(NSString *)rtcpUserId authorization:(NSString *)authorization rtcpMeetingsRemoteConfigs:(MeetingsCoreRTCPMeetingsRemoteConfigs *)rtcpMeetingsRemoteConfigs rtcpWMSConfiguration:(MeetingsCoreRTCPWMSConfiguration * _Nullable)rtcpWMSConfiguration completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("doInitMeetingSession(clientOtp:callKey:rtcpUserId:authorization:rtcpMeetingsRemoteConfigs:rtcpWMSConfiguration:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isAllMeetingParticipantsAudioDisabled __attribute__((swift_name("isAllMeetingParticipantsAudioDisabled()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isAllMeetingParticipantsAudioEnabled __attribute__((swift_name("isAllMeetingParticipantsAudioEnabled()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isAssignPrimaryAdminMembersAvailable __attribute__((swift_name("isAssignPrimaryAdminMembersAvailable()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isMeetingConnectionEstablished __attribute__((swift_name("isMeetingConnectionEstablished()")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isMemberRequestedToSpeakUserId:(NSString *)userId __attribute__((swift_name("isMemberRequestedToSpeak(userId:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)isScreenSharingInProgress __attribute__((swift_name("isScreenSharingInProgress()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinMeetingUserDisplayName:(NSString * _Nullable)userDisplayName completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("joinMeeting(userDisplayName:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id<MeetingsCoreKotlinx_coroutines_coreFlow>> *)otherSpeakersVisibilityRestrictedInSpotlight __attribute__((swift_name("otherSpeakersVisibilityRestrictedInSpotlight()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)rejectAllJoinRequestWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("rejectAllJoinRequest(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)rejectJoinRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("rejectJoinRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)rejectSpeakRequestUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("rejectSpeakRequest(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeFromSpotlightUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("removeFromSpotlight(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeSecondaryAdminUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("removeSecondaryAdmin(userId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)replaceAudioInputForceInitAudioManager:(BOOL)forceInitAudioManager completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("replaceAudioInput(forceInitAudioManager:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)replaceVideoInputVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("replaceVideoInput(videoCaptureSpec:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestToJoinMeetingUserDisplayName:(NSString * _Nullable)userDisplayName completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("requestToJoinMeeting(userDisplayName:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestToSpeakWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("requestToSpeak(completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)resizeScreenShareContentVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec __attribute__((swift_name("resizeScreenShareContent(videoCaptureSpec:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)restrictEnableAudioWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("restrictEnableAudio(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)ringAllWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("ringAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)ringUserUserId:(NSString *)userId completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("ringUser(userId:completionHandler:)")));
- (void)setOnGetDisplayNameListenerGetUserDisplayNames:(id<MeetingsCoreKotlinSuspendFunction1>)getUserDisplayNames __attribute__((swift_name("setOnGetDisplayNameListener(getUserDisplayNames:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startMeetingMeetingTitle:(NSString *)meetingTitle userDisplayName:(NSString * _Nullable)userDisplayName completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startMeeting(meetingTitle:userDisplayName:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startScreenShareVideoCaptureSpec:(MeetingsCoreVideoCaptureSpec *)videoCaptureSpec completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startScreenShare(videoCaptureSpec:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)stopScreenShareWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("stopScreenShare(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)subscribeVideosUserIds:(NSArray<NSString *> *)userIds completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("subscribeVideos(userIds:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)unRestrictEnableAudioWithCompletionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("unRestrictEnableAudio(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAudioStatusEnable:(BOOL)enable completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAudioStatus(enable:completionHandler:)")));
- (MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> *)updateOutputAudioStatusEnable:(BOOL)enable __attribute__((swift_name("updateOutputAudioStatus(enable:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateVideoStatusEnable:(BOOL)enable completionHandler:(void (^)(MeetingsCoreRTCPMeetingsClientResult<MeetingsCoreKotlinUnit *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateVideoStatus(enable:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPScreenShareVideoCapturerManager")))
@interface MeetingsCoreRTCPScreenShareVideoCapturerManager : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)rTCPScreenShareVideoCapturerManager __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPScreenShareVideoCapturerManager *shared __attribute__((swift_name("shared")));
- (MeetingsCoreKotlinPair<RTCVideoSource *, RTCVideoCapturer *> *)getVideoCapturerDetails __attribute__((swift_name("getVideoCapturerDetails()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionsUtil")))
@interface MeetingsCorePermissionsUtil : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)permissionsUtil __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCorePermissionsUtil *shared __attribute__((swift_name("shared")));
- (BOOL)needAudioPermission __attribute__((swift_name("needAudioPermission()")));
- (BOOL)needVideoPermission __attribute__((swift_name("needVideoPermission()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactory")))
@interface MeetingsCoreDatabaseDriverFactory : MeetingsCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<MeetingsCoreRuntimeSqlDriver>)createDriver __attribute__((swift_name("createDriver()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ClientStatsResponse")))
@interface MeetingsCoreClientStatsResponse : MeetingsCoreBase
- (instancetype)initWithStatsMaxSize:(MeetingsCoreInt * _Nullable)statsMaxSize statsInterval:(MeetingsCoreLong * _Nullable)statsInterval __attribute__((swift_name("init(statsMaxSize:statsInterval:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MeetingsCoreClientStatsResponseCompanion *companion __attribute__((swift_name("companion")));
- (MeetingsCoreClientStatsResponse *)doCopyStatsMaxSize:(MeetingsCoreInt * _Nullable)statsMaxSize statsInterval:(MeetingsCoreLong * _Nullable)statsInterval __attribute__((swift_name("doCopy(statsMaxSize:statsInterval:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCoreLong * _Nullable statsInterval __attribute__((swift_name("statsInterval")));
@property (readonly) MeetingsCoreInt * _Nullable statsMaxSize __attribute__((swift_name("statsMaxSize")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ClientStatsResponse.Companion")))
@interface MeetingsCoreClientStatsResponseCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreClientStatsResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetParticipantsDetailsResponse")))
@interface MeetingsCoreGetParticipantsDetailsResponse : MeetingsCoreBase
- (instancetype)initWithParticipantList:(NSArray<MeetingsCoreKotlinx_serialization_jsonJsonElement *> * _Nullable)participantList __attribute__((swift_name("init(participantList:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MeetingsCoreGetParticipantsDetailsResponseCompanion *companion __attribute__((swift_name("companion")));
- (MeetingsCoreGetParticipantsDetailsResponse *)doCopyParticipantList:(NSArray<MeetingsCoreKotlinx_serialization_jsonJsonElement *> * _Nullable)participantList __attribute__((swift_name("doCopy(participantList:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<MeetingsCoreKotlinx_serialization_jsonJsonElement *> * _Nullable participantList __attribute__((swift_name("participantList")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetParticipantsDetailsResponse.Companion")))
@interface MeetingsCoreGetParticipantsDetailsResponseCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreGetParticipantsDetailsResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HandleRemoveUserResponse")))
@interface MeetingsCoreHandleRemoveUserResponse : MeetingsCoreBase
- (instancetype)initWithConferenceId:(NSString * _Nullable)conferenceId module:(NSString * _Nullable)module userIds:(NSArray<NSString *> * _Nullable)userIds messageTime:(MeetingsCoreLong * _Nullable)messageTime actionId:(NSString * _Nullable)actionId __attribute__((swift_name("init(conferenceId:module:userIds:messageTime:actionId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MeetingsCoreHandleRemoveUserResponseCompanion *companion __attribute__((swift_name("companion")));
- (MeetingsCoreHandleRemoveUserResponse *)doCopyConferenceId:(NSString * _Nullable)conferenceId module:(NSString * _Nullable)module userIds:(NSArray<NSString *> * _Nullable)userIds messageTime:(MeetingsCoreLong * _Nullable)messageTime actionId:(NSString * _Nullable)actionId __attribute__((swift_name("doCopy(conferenceId:module:userIds:messageTime:actionId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable actionId __attribute__((swift_name("actionId")));
@property (readonly) NSString * _Nullable conferenceId __attribute__((swift_name("conferenceId")));
@property (readonly) MeetingsCoreLong * _Nullable messageTime __attribute__((swift_name("messageTime")));
@property (readonly) NSString * _Nullable module __attribute__((swift_name("module")));
@property (readonly) NSArray<NSString *> * _Nullable userIds __attribute__((swift_name("userIds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HandleRemoveUserResponse.Companion")))
@interface MeetingsCoreHandleRemoveUserResponseCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreHandleRemoveUserResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClientException")))
@interface MeetingsCoreRTCPMeetingsClientException : MeetingsCoreKotlinException
- (instancetype)initWithMessage:(NSString * _Nullable)message t:(MeetingsCoreKotlinThrowable * _Nullable)t __attribute__((swift_name("init(message:t:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClientResult")))
@interface MeetingsCoreRTCPMeetingsClientResult<ResultType> : MeetingsCoreBase
@property (class, readonly, getter=companion) MeetingsCoreRTCPMeetingsClientResultCompanion *companion __attribute__((swift_name("companion")));
- (MeetingsCoreRTCPMeetingsClientResult<id> *)doCopyData:(id _Nullable)data __attribute__((swift_name("doCopy(data:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id> *)mapTransform:(id _Nullable (^)(ResultType _Nullable))transform __attribute__((swift_name("map(transform:)")));
- (MeetingsCoreRTCPMeetingsClientResult<ResultType> *)onCompleteOnComplete:(void (^)(void))onComplete __attribute__((swift_name("onComplete(onComplete:)")));
- (MeetingsCoreRTCPMeetingsClientResult<ResultType> *)onFailureOnFailure:(void (^)(MeetingsCoreRTCPMeetingsClientResultError *))onFailure __attribute__((swift_name("onFailure(onFailure:)")));
- (MeetingsCoreRTCPMeetingsClientResult<ResultType> *)onSuccessOnSuccess:(void (^)(ResultType _Nullable))onSuccess __attribute__((swift_name("onSuccess(onSuccess:)")));
@property (readonly) ResultType _Nullable data __attribute__((swift_name("data")));
@property (readonly) MeetingsCoreRTCPMeetingsClientResultError * _Nullable error __attribute__((swift_name("error")));
@property (readonly) BOOL isSuccess __attribute__((swift_name("isSuccess")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClientResultCompanion")))
@interface MeetingsCoreRTCPMeetingsClientResultCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRTCPMeetingsClientResultCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreRTCPMeetingsClientResult<id> *)failureError:(MeetingsCoreRTCPMeetingsClientResultError *)error __attribute__((swift_name("failure(error:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id> *)failureThrowable:(MeetingsCoreKotlinThrowable *)throwable __attribute__((swift_name("failure(throwable:)")));
- (MeetingsCoreRTCPMeetingsClientResult<id> *)successData:(id _Nullable)data __attribute__((swift_name("success(data:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClientResultError")))
@interface MeetingsCoreRTCPMeetingsClientResultError : MeetingsCoreBase
- (instancetype)initWithResponseCode:(MeetingsCoreInt * _Nullable)responseCode error:(NSString * _Nullable)error message:(NSString * _Nullable)message code:(MeetingsCoreInt * _Nullable)code cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(responseCode:error:message:code:cause:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCoreKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) MeetingsCoreInt * _Nullable code __attribute__((swift_name("code")));
@property (readonly) NSString * _Nullable error __attribute__((swift_name("error")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@property (readonly) MeetingsCoreInt * _Nullable responseCode __attribute__((swift_name("responseCode")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol MeetingsCoreKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface MeetingsCoreKotlinEnum<E> : MeetingsCoreBase <MeetingsCoreKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MeetingsCoreKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AVStatusMode")))
@interface MeetingsCoreAVStatusMode : MeetingsCoreKotlinEnum<MeetingsCoreAVStatusMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreAVStatusModeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreAVStatusMode *audio __attribute__((swift_name("audio")));
@property (class, readonly) MeetingsCoreAVStatusMode *video __attribute__((swift_name("video")));
+ (MeetingsCoreKotlinArray<MeetingsCoreAVStatusMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreAVStatusMode *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AVStatusMode.Companion")))
@interface MeetingsCoreAVStatusModeCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreAVStatusModeCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreAVStatusMode *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioEnabledDisabledNotifierData")))
@interface MeetingsCoreAudioEnabledDisabledNotifierData : MeetingsCoreBase
- (instancetype)initWithStatus:(MeetingsCoreAudioEnabledDisabledNotifierDataStatus *)status actionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("init(status:actionUserId:actionUserName:primaryAdminId:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreAudioEnabledDisabledNotifierData *)doCopyStatus:(MeetingsCoreAudioEnabledDisabledNotifierDataStatus *)status actionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("doCopy(status:actionUserId:actionUserName:primaryAdminId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *actionUserId __attribute__((swift_name("actionUserId")));
@property (readonly) NSString *actionUserName __attribute__((swift_name("actionUserName")));
@property (readonly) NSString *primaryAdminId __attribute__((swift_name("primaryAdminId")));
@property (readonly) MeetingsCoreAudioEnabledDisabledNotifierDataStatus *status __attribute__((swift_name("status")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudioEnabledDisabledNotifierData.Status")))
@interface MeetingsCoreAudioEnabledDisabledNotifierDataStatus : MeetingsCoreKotlinEnum<MeetingsCoreAudioEnabledDisabledNotifierDataStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreAudioEnabledDisabledNotifierDataStatus *disabled __attribute__((swift_name("disabled")));
@property (class, readonly) MeetingsCoreAudioEnabledDisabledNotifierDataStatus *enabled __attribute__((swift_name("enabled")));
@property (class, readonly) MeetingsCoreAudioEnabledDisabledNotifierDataStatus *allowEnable __attribute__((swift_name("allowEnable")));
+ (MeetingsCoreKotlinArray<MeetingsCoreAudioEnabledDisabledNotifierDataStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreAudioEnabledDisabledNotifierDataStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CameraFace")))
@interface MeetingsCoreCameraFace : MeetingsCoreKotlinEnum<MeetingsCoreCameraFace *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreCameraFace *front __attribute__((swift_name("front")));
@property (class, readonly) MeetingsCoreCameraFace *back __attribute__((swift_name("back")));
+ (MeetingsCoreKotlinArray<MeetingsCoreCameraFace *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreCameraFace *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConferenceACL")))
@interface MeetingsCoreConferenceACL : MeetingsCoreKotlinEnum<MeetingsCoreConferenceACL *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreConferenceACLCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreConferenceACL *enableWaitingRoom __attribute__((swift_name("enableWaitingRoom")));
@property (class, readonly) MeetingsCoreConferenceACL *muteAllParticipants __attribute__((swift_name("muteAllParticipants")));
@property (class, readonly) MeetingsCoreConferenceACL *restrictUnMuteAudio __attribute__((swift_name("restrictUnMuteAudio")));
@property (class, readonly) MeetingsCoreConferenceACL *restrictUnMuteVideo __attribute__((swift_name("restrictUnMuteVideo")));
@property (class, readonly) MeetingsCoreConferenceACL *restrictScreenShare __attribute__((swift_name("restrictScreenShare")));
@property (class, readonly) MeetingsCoreConferenceACL *restrictAssignCoHost __attribute__((swift_name("restrictAssignCoHost")));
@property (class, readonly) MeetingsCoreConferenceACL *disallowScreenShare __attribute__((swift_name("disallowScreenShare")));
@property (class, readonly) MeetingsCoreConferenceACL *restrictVideo __attribute__((swift_name("restrictVideo")));
+ (MeetingsCoreKotlinArray<MeetingsCoreConferenceACL *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreConferenceACL *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConferenceACL.Companion")))
@interface MeetingsCoreConferenceACLCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreConferenceACLCompanion *shared __attribute__((swift_name("shared")));
- (BOOL)isDisallowScreenShareAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isDisallowScreenShare(acl:)")));
- (BOOL)isEnableWaitingRoomAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isEnableWaitingRoom(acl:)")));
- (BOOL)isMuteAllParticipantsAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isMuteAllParticipants(acl:)")));
- (BOOL)isRestrictAssignCoHostAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isRestrictAssignCoHost(acl:)")));
- (BOOL)isRestrictScreenShareAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isRestrictScreenShare(acl:)")));
- (BOOL)isRestrictUnMuteAudioAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isRestrictUnMuteAudio(acl:)")));
- (BOOL)isRestrictUnMuteVideoAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isRestrictUnMuteVideo(acl:)")));
- (BOOL)isRestrictVideoAcl:(MeetingsCoreInt * _Nullable)acl __attribute__((swift_name("isRestrictVideo(acl:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreatorDetails")))
@interface MeetingsCoreCreatorDetails : MeetingsCoreBase
- (instancetype)initWithId:(NSString * _Nullable)id __attribute__((swift_name("init(id:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreCreatorDetails *)doCopyId:(NSString * _Nullable)id __attribute__((swift_name("doCopy(id:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnableAudioRestrictedNotifierData")))
@interface MeetingsCoreEnableAudioRestrictedNotifierData : MeetingsCoreBase
- (instancetype)initWithScope:(MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *)scope actionUserId:(NSString * _Nullable)actionUserId actionUserName:(NSString * _Nullable)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("init(scope:actionUserId:actionUserName:primaryAdminId:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreEnableAudioRestrictedNotifierData *)doCopyScope:(MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *)scope actionUserId:(NSString * _Nullable)actionUserId actionUserName:(NSString * _Nullable)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("doCopy(scope:actionUserId:actionUserName:primaryAdminId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable actionUserId __attribute__((swift_name("actionUserId")));
@property (readonly) NSString * _Nullable actionUserName __attribute__((swift_name("actionUserName")));
@property (readonly) NSString *primaryAdminId __attribute__((swift_name("primaryAdminId")));
@property (readonly) MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnableAudioRestrictedNotifierData.RestrictionScope")))
@interface MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope : MeetingsCoreKotlinEnum<MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *all __attribute__((swift_name("all")));
@property (class, readonly) MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *you __attribute__((swift_name("you")));
+ (MeetingsCoreKotlinArray<MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreEnableAudioRestrictedNotifierDataRestrictionScope *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExpiryDurationRemainsData")))
@interface MeetingsCoreExpiryDurationRemainsData : MeetingsCoreBase
- (instancetype)initWithTriggerTime:(int64_t)triggerTime remainingDuration:(int64_t)remainingDuration __attribute__((swift_name("init(triggerTime:remainingDuration:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreExpiryDurationRemainsData *)doCopyTriggerTime:(int64_t)triggerTime remainingDuration:(int64_t)remainingDuration __attribute__((swift_name("doCopy(triggerTime:remainingDuration:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t remainingDuration __attribute__((swift_name("remainingDuration")));
@property (readonly) int64_t triggerTime __attribute__((swift_name("triggerTime")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GlobalSettings")))
@interface MeetingsCoreGlobalSettings : MeetingsCoreBase
- (instancetype)initWithIsStereoDownStreamEnabled:(BOOL)isStereoDownStreamEnabled isComputerAudioEnabled:(BOOL)isComputerAudioEnabled isLayoutSwitchEnabled:(BOOL)isLayoutSwitchEnabled isSpotlightAudioRestrictionEnabled:(BOOL)isSpotlightAudioRestrictionEnabled isNotebookLHSEnabled:(BOOL)isNotebookLHSEnabled isHighResolutionEnabled:(BOOL)isHighResolutionEnabled isThreadsInConferenceEnabled:(BOOL)isThreadsInConferenceEnabled isPersonalConfigEnabled:(BOOL)isPersonalConfigEnabled isParallelConnectionEnabled:(BOOL)isParallelConnectionEnabled isCoHostEnabled:(BOOL)isCoHostEnabled isDownstreamConnectionEnabled:(BOOL)isDownstreamConnectionEnabled isNomenclatureEnabled:(BOOL)isNomenclatureEnabled isUnifiedMixingEnabled:(BOOL)isUnifiedMixingEnabled isBubbleUIEnabled:(BOOL)isBubbleUIEnabled isDefaultGridEnabled:(BOOL)isDefaultGridEnabled isCSRCProfilePicEnabled:(BOOL)isCSRCProfilePicEnabled isTrackCloseEnabled:(BOOL)isTrackCloseEnabled isNotebookIntegrationEnabled:(BOOL)isNotebookIntegrationEnabled isCloseTrackWithoutConnectionEnabled:(BOOL)isCloseTrackWithoutConnectionEnabled isKickoutEnabled:(BOOL)isKickoutEnabled isUnifiedSDPEnabled:(BOOL)isUnifiedSDPEnabled isBookmarkEnabled:(BOOL)isBookmarkEnabled isPersonalConferenceChatIndependencyAllowed:(BOOL)isPersonalConferenceChatIndependencyAllowed isDeviceListenerEnabled:(BOOL)isDeviceListenerEnabled isInstantConferenceInviteAllowed:(BOOL)isInstantConferenceInviteAllowed isHostRejoinEnabled:(BOOL)isHostRejoinEnabled isVideoEffectsEnabled:(BOOL)isVideoEffectsEnabled isStereoUpstreamEnabled:(BOOL)isStereoUpstreamEnabled isChatSwitchEnabled:(BOOL)isChatSwitchEnabled isSmartAudioConferenceEnabled:(BOOL)isSmartAudioConferenceEnabled isCoHostStartEnabled:(BOOL)isCoHostStartEnabled isAudioStreamingEnabled:(BOOL)isAudioStreamingEnabled isAssignAsHostAllowed:(BOOL)isAssignAsHostAllowed isEventLogEnabled:(BOOL)isEventLogEnabled isAnimeSmileyEnabled:(BOOL)isAnimeSmileyEnabled isRecordingAllowed:(BOOL)isRecordingAllowed isRecordingEnabled:(BOOL)isRecordingEnabled isMuteUserEnabled:(BOOL)isMuteUserEnabled isStreamingEnabled:(BOOL)isStreamingEnabled isEventNomenclatureEnabled:(BOOL)isEventNomenclatureEnabled isScreenShareLayoutEnabled:(BOOL)isScreenShareLayoutEnabled isConfigurationsEnabled:(BOOL)isConfigurationsEnabled isSwitchToVideoAllowed:(BOOL)isSwitchToVideoAllowed isAssociateResourceEnabled:(BOOL)isAssociateResourceEnabled isSpecialReactionsEnabled:(BOOL)isSpecialReactionsEnabled isWhiteBoardAllowed:(BOOL)isWhiteBoardAllowed isGuestConferenceEnabled:(BOOL)isGuestConferenceEnabled isNewAudioGridViewEnabled:(BOOL)isNewAudioGridViewEnabled isSmartConferenceEnabled:(BOOL)isSmartConferenceEnabled isSecondaryAdminAudioRestrictionEnabled:(BOOL)isSecondaryAdminAudioRestrictionEnabled isGridSubscriberEnabled:(BOOL)isGridSubscriberEnabled isGridViewEnabled:(BOOL)isGridViewEnabled isPinUserVideoEnabled:(BOOL)isPinUserVideoEnabled isSpotlightEnabled:(BOOL)isSpotlightEnabled isLowBandwidthModeEnabled:(BOOL)isLowBandwidthModeEnabled isSetAsHostEnabled:(BOOL)isSetAsHostEnabled isPresentationRequestsEnabled:(BOOL)isPresentationRequestsEnabled isMuteAllEnabled:(BOOL)isMuteAllEnabled isVideoEffectsSettingsEnabled:(BOOL)isVideoEffectsSettingsEnabled isAddDeviceEnabled:(BOOL)isAddDeviceEnabled isGroupCallFocusModeAllowed:(BOOL)isGroupCallFocusModeAllowed isGifsEnabled:(BOOL)isGifsEnabled isStatsEnabled:(BOOL)isStatsEnabled isActiveSpeakerInGridViewEnabled:(BOOL)isActiveSpeakerInGridViewEnabled __attribute__((swift_name("init(isStereoDownStreamEnabled:isComputerAudioEnabled:isLayoutSwitchEnabled:isSpotlightAudioRestrictionEnabled:isNotebookLHSEnabled:isHighResolutionEnabled:isThreadsInConferenceEnabled:isPersonalConfigEnabled:isParallelConnectionEnabled:isCoHostEnabled:isDownstreamConnectionEnabled:isNomenclatureEnabled:isUnifiedMixingEnabled:isBubbleUIEnabled:isDefaultGridEnabled:isCSRCProfilePicEnabled:isTrackCloseEnabled:isNotebookIntegrationEnabled:isCloseTrackWithoutConnectionEnabled:isKickoutEnabled:isUnifiedSDPEnabled:isBookmarkEnabled:isPersonalConferenceChatIndependencyAllowed:isDeviceListenerEnabled:isInstantConferenceInviteAllowed:isHostRejoinEnabled:isVideoEffectsEnabled:isStereoUpstreamEnabled:isChatSwitchEnabled:isSmartAudioConferenceEnabled:isCoHostStartEnabled:isAudioStreamingEnabled:isAssignAsHostAllowed:isEventLogEnabled:isAnimeSmileyEnabled:isRecordingAllowed:isRecordingEnabled:isMuteUserEnabled:isStreamingEnabled:isEventNomenclatureEnabled:isScreenShareLayoutEnabled:isConfigurationsEnabled:isSwitchToVideoAllowed:isAssociateResourceEnabled:isSpecialReactionsEnabled:isWhiteBoardAllowed:isGuestConferenceEnabled:isNewAudioGridViewEnabled:isSmartConferenceEnabled:isSecondaryAdminAudioRestrictionEnabled:isGridSubscriberEnabled:isGridViewEnabled:isPinUserVideoEnabled:isSpotlightEnabled:isLowBandwidthModeEnabled:isSetAsHostEnabled:isPresentationRequestsEnabled:isMuteAllEnabled:isVideoEffectsSettingsEnabled:isAddDeviceEnabled:isGroupCallFocusModeAllowed:isGifsEnabled:isStatsEnabled:isActiveSpeakerInGridViewEnabled:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreGlobalSettings *)doCopyIsStereoDownStreamEnabled:(BOOL)isStereoDownStreamEnabled isComputerAudioEnabled:(BOOL)isComputerAudioEnabled isLayoutSwitchEnabled:(BOOL)isLayoutSwitchEnabled isSpotlightAudioRestrictionEnabled:(BOOL)isSpotlightAudioRestrictionEnabled isNotebookLHSEnabled:(BOOL)isNotebookLHSEnabled isHighResolutionEnabled:(BOOL)isHighResolutionEnabled isThreadsInConferenceEnabled:(BOOL)isThreadsInConferenceEnabled isPersonalConfigEnabled:(BOOL)isPersonalConfigEnabled isParallelConnectionEnabled:(BOOL)isParallelConnectionEnabled isCoHostEnabled:(BOOL)isCoHostEnabled isDownstreamConnectionEnabled:(BOOL)isDownstreamConnectionEnabled isNomenclatureEnabled:(BOOL)isNomenclatureEnabled isUnifiedMixingEnabled:(BOOL)isUnifiedMixingEnabled isBubbleUIEnabled:(BOOL)isBubbleUIEnabled isDefaultGridEnabled:(BOOL)isDefaultGridEnabled isCSRCProfilePicEnabled:(BOOL)isCSRCProfilePicEnabled isTrackCloseEnabled:(BOOL)isTrackCloseEnabled isNotebookIntegrationEnabled:(BOOL)isNotebookIntegrationEnabled isCloseTrackWithoutConnectionEnabled:(BOOL)isCloseTrackWithoutConnectionEnabled isKickoutEnabled:(BOOL)isKickoutEnabled isUnifiedSDPEnabled:(BOOL)isUnifiedSDPEnabled isBookmarkEnabled:(BOOL)isBookmarkEnabled isPersonalConferenceChatIndependencyAllowed:(BOOL)isPersonalConferenceChatIndependencyAllowed isDeviceListenerEnabled:(BOOL)isDeviceListenerEnabled isInstantConferenceInviteAllowed:(BOOL)isInstantConferenceInviteAllowed isHostRejoinEnabled:(BOOL)isHostRejoinEnabled isVideoEffectsEnabled:(BOOL)isVideoEffectsEnabled isStereoUpstreamEnabled:(BOOL)isStereoUpstreamEnabled isChatSwitchEnabled:(BOOL)isChatSwitchEnabled isSmartAudioConferenceEnabled:(BOOL)isSmartAudioConferenceEnabled isCoHostStartEnabled:(BOOL)isCoHostStartEnabled isAudioStreamingEnabled:(BOOL)isAudioStreamingEnabled isAssignAsHostAllowed:(BOOL)isAssignAsHostAllowed isEventLogEnabled:(BOOL)isEventLogEnabled isAnimeSmileyEnabled:(BOOL)isAnimeSmileyEnabled isRecordingAllowed:(BOOL)isRecordingAllowed isRecordingEnabled:(BOOL)isRecordingEnabled isMuteUserEnabled:(BOOL)isMuteUserEnabled isStreamingEnabled:(BOOL)isStreamingEnabled isEventNomenclatureEnabled:(BOOL)isEventNomenclatureEnabled isScreenShareLayoutEnabled:(BOOL)isScreenShareLayoutEnabled isConfigurationsEnabled:(BOOL)isConfigurationsEnabled isSwitchToVideoAllowed:(BOOL)isSwitchToVideoAllowed isAssociateResourceEnabled:(BOOL)isAssociateResourceEnabled isSpecialReactionsEnabled:(BOOL)isSpecialReactionsEnabled isWhiteBoardAllowed:(BOOL)isWhiteBoardAllowed isGuestConferenceEnabled:(BOOL)isGuestConferenceEnabled isNewAudioGridViewEnabled:(BOOL)isNewAudioGridViewEnabled isSmartConferenceEnabled:(BOOL)isSmartConferenceEnabled isSecondaryAdminAudioRestrictionEnabled:(BOOL)isSecondaryAdminAudioRestrictionEnabled isGridSubscriberEnabled:(BOOL)isGridSubscriberEnabled isGridViewEnabled:(BOOL)isGridViewEnabled isPinUserVideoEnabled:(BOOL)isPinUserVideoEnabled isSpotlightEnabled:(BOOL)isSpotlightEnabled isLowBandwidthModeEnabled:(BOOL)isLowBandwidthModeEnabled isSetAsHostEnabled:(BOOL)isSetAsHostEnabled isPresentationRequestsEnabled:(BOOL)isPresentationRequestsEnabled isMuteAllEnabled:(BOOL)isMuteAllEnabled isVideoEffectsSettingsEnabled:(BOOL)isVideoEffectsSettingsEnabled isAddDeviceEnabled:(BOOL)isAddDeviceEnabled isGroupCallFocusModeAllowed:(BOOL)isGroupCallFocusModeAllowed isGifsEnabled:(BOOL)isGifsEnabled isStatsEnabled:(BOOL)isStatsEnabled isActiveSpeakerInGridViewEnabled:(BOOL)isActiveSpeakerInGridViewEnabled __attribute__((swift_name("doCopy(isStereoDownStreamEnabled:isComputerAudioEnabled:isLayoutSwitchEnabled:isSpotlightAudioRestrictionEnabled:isNotebookLHSEnabled:isHighResolutionEnabled:isThreadsInConferenceEnabled:isPersonalConfigEnabled:isParallelConnectionEnabled:isCoHostEnabled:isDownstreamConnectionEnabled:isNomenclatureEnabled:isUnifiedMixingEnabled:isBubbleUIEnabled:isDefaultGridEnabled:isCSRCProfilePicEnabled:isTrackCloseEnabled:isNotebookIntegrationEnabled:isCloseTrackWithoutConnectionEnabled:isKickoutEnabled:isUnifiedSDPEnabled:isBookmarkEnabled:isPersonalConferenceChatIndependencyAllowed:isDeviceListenerEnabled:isInstantConferenceInviteAllowed:isHostRejoinEnabled:isVideoEffectsEnabled:isStereoUpstreamEnabled:isChatSwitchEnabled:isSmartAudioConferenceEnabled:isCoHostStartEnabled:isAudioStreamingEnabled:isAssignAsHostAllowed:isEventLogEnabled:isAnimeSmileyEnabled:isRecordingAllowed:isRecordingEnabled:isMuteUserEnabled:isStreamingEnabled:isEventNomenclatureEnabled:isScreenShareLayoutEnabled:isConfigurationsEnabled:isSwitchToVideoAllowed:isAssociateResourceEnabled:isSpecialReactionsEnabled:isWhiteBoardAllowed:isGuestConferenceEnabled:isNewAudioGridViewEnabled:isSmartConferenceEnabled:isSecondaryAdminAudioRestrictionEnabled:isGridSubscriberEnabled:isGridViewEnabled:isPinUserVideoEnabled:isSpotlightEnabled:isLowBandwidthModeEnabled:isSetAsHostEnabled:isPresentationRequestsEnabled:isMuteAllEnabled:isVideoEffectsSettingsEnabled:isAddDeviceEnabled:isGroupCallFocusModeAllowed:isGifsEnabled:isStatsEnabled:isActiveSpeakerInGridViewEnabled:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isActiveSpeakerInGridViewEnabled __attribute__((swift_name("isActiveSpeakerInGridViewEnabled")));
@property (readonly) BOOL isAddDeviceEnabled __attribute__((swift_name("isAddDeviceEnabled")));
@property (readonly) BOOL isAnimeSmileyEnabled __attribute__((swift_name("isAnimeSmileyEnabled")));
@property (readonly) BOOL isAssignAsHostAllowed __attribute__((swift_name("isAssignAsHostAllowed")));
@property (readonly) BOOL isAssociateResourceEnabled __attribute__((swift_name("isAssociateResourceEnabled")));
@property (readonly) BOOL isAudioStreamingEnabled __attribute__((swift_name("isAudioStreamingEnabled")));
@property (readonly) BOOL isBookmarkEnabled __attribute__((swift_name("isBookmarkEnabled")));
@property (readonly) BOOL isBubbleUIEnabled __attribute__((swift_name("isBubbleUIEnabled")));
@property (readonly) BOOL isCSRCProfilePicEnabled __attribute__((swift_name("isCSRCProfilePicEnabled")));
@property (readonly) BOOL isChatSwitchEnabled __attribute__((swift_name("isChatSwitchEnabled")));
@property (readonly) BOOL isCloseTrackWithoutConnectionEnabled __attribute__((swift_name("isCloseTrackWithoutConnectionEnabled")));
@property (readonly) BOOL isCoHostEnabled __attribute__((swift_name("isCoHostEnabled")));
@property (readonly) BOOL isCoHostStartEnabled __attribute__((swift_name("isCoHostStartEnabled")));
@property (readonly) BOOL isComputerAudioEnabled __attribute__((swift_name("isComputerAudioEnabled")));
@property (readonly) BOOL isConfigurationsEnabled __attribute__((swift_name("isConfigurationsEnabled")));
@property (readonly) BOOL isDefaultGridViewEnabled __attribute__((swift_name("isDefaultGridViewEnabled")));
@property (readonly) BOOL isDeviceListenerEnabled __attribute__((swift_name("isDeviceListenerEnabled")));
@property (readonly) BOOL isDownstreamConnectionEnabled __attribute__((swift_name("isDownstreamConnectionEnabled")));
@property (readonly) BOOL isEventLogEnabled __attribute__((swift_name("isEventLogEnabled")));
@property (readonly) BOOL isEventNomenclatureEnabled __attribute__((swift_name("isEventNomenclatureEnabled")));
@property (readonly) BOOL isGifsEnabled __attribute__((swift_name("isGifsEnabled")));
@property (readonly) BOOL isGridSubscriberEnabled __attribute__((swift_name("isGridSubscriberEnabled")));
@property (readonly) BOOL isGridViewEnabled __attribute__((swift_name("isGridViewEnabled")));
@property (readonly) BOOL isGroupCallFocusModeAllowed __attribute__((swift_name("isGroupCallFocusModeAllowed")));
@property (readonly) BOOL isGuestConferenceEnabled __attribute__((swift_name("isGuestConferenceEnabled")));
@property (readonly) BOOL isHighResolutionEnabled __attribute__((swift_name("isHighResolutionEnabled")));
@property (readonly) BOOL isHostRejoinEnabled __attribute__((swift_name("isHostRejoinEnabled")));
@property (readonly) BOOL isInstantConferenceInviteAllowed __attribute__((swift_name("isInstantConferenceInviteAllowed")));
@property (readonly) BOOL isKickoutEnabled __attribute__((swift_name("isKickoutEnabled")));
@property (readonly) BOOL isLayoutSwitchEnabled __attribute__((swift_name("isLayoutSwitchEnabled")));
@property (readonly) BOOL isLowBandwidthModeEnabled __attribute__((swift_name("isLowBandwidthModeEnabled")));
@property (readonly) BOOL isMuteAllEnabled __attribute__((swift_name("isMuteAllEnabled")));
@property (readonly) BOOL isMuteUserEnabled __attribute__((swift_name("isMuteUserEnabled")));
@property (readonly) BOOL isNewAudioGridViewEnabled __attribute__((swift_name("isNewAudioGridViewEnabled")));
@property (readonly) BOOL isNomenclatureEnabled __attribute__((swift_name("isNomenclatureEnabled")));
@property (readonly) BOOL isNotebookIntegrationEnabled __attribute__((swift_name("isNotebookIntegrationEnabled")));
@property (readonly) BOOL isNotebookLHSEnabled __attribute__((swift_name("isNotebookLHSEnabled")));
@property (readonly) BOOL isParallelConnectionEnabled __attribute__((swift_name("isParallelConnectionEnabled")));
@property (readonly) BOOL isPersonalConferenceChatIndependencyAllowed __attribute__((swift_name("isPersonalConferenceChatIndependencyAllowed")));
@property (readonly) BOOL isPersonalConfigEnabled __attribute__((swift_name("isPersonalConfigEnabled")));
@property (readonly) BOOL isPinUserVideoEnabled __attribute__((swift_name("isPinUserVideoEnabled")));
@property (readonly) BOOL isPresentationRequestsEnabled __attribute__((swift_name("isPresentationRequestsEnabled")));
@property (readonly) BOOL isRecordingAllowed __attribute__((swift_name("isRecordingAllowed")));
@property (readonly) BOOL isRecordingEnabled __attribute__((swift_name("isRecordingEnabled")));
@property (readonly) BOOL isScreenShareLayoutEnabled __attribute__((swift_name("isScreenShareLayoutEnabled")));
@property (readonly) BOOL isSecondaryAdminAudioRestrictionEnabled __attribute__((swift_name("isSecondaryAdminAudioRestrictionEnabled")));
@property (readonly) BOOL isSetAsHostEnabled __attribute__((swift_name("isSetAsHostEnabled")));
@property (readonly) BOOL isSmartAudioConferenceEnabled __attribute__((swift_name("isSmartAudioConferenceEnabled")));
@property (readonly) BOOL isSmartConferenceEnabled __attribute__((swift_name("isSmartConferenceEnabled")));
@property (readonly) BOOL isSpecialReactionsEnabled __attribute__((swift_name("isSpecialReactionsEnabled")));
@property (readonly) BOOL isSpotlightAudioRestrictionEnabled __attribute__((swift_name("isSpotlightAudioRestrictionEnabled")));
@property (readonly) BOOL isSpotlightEnabled __attribute__((swift_name("isSpotlightEnabled")));
@property (readonly) BOOL isStatsEnabled __attribute__((swift_name("isStatsEnabled")));
@property (readonly) BOOL isStereoDownStreamEnabled __attribute__((swift_name("isStereoDownStreamEnabled")));
@property (readonly) BOOL isStereoUpstreamEnabled __attribute__((swift_name("isStereoUpstreamEnabled")));
@property (readonly) BOOL isStreamingEnabled __attribute__((swift_name("isStreamingEnabled")));
@property (readonly) BOOL isSwitchToVideoAllowed __attribute__((swift_name("isSwitchToVideoAllowed")));
@property (readonly) BOOL isThreadsInConferenceEnabled __attribute__((swift_name("isThreadsInConferenceEnabled")));
@property (readonly) BOOL isTrackCloseEnabled __attribute__((swift_name("isTrackCloseEnabled")));
@property (readonly) BOOL isUnifiedMixingEnabled __attribute__((swift_name("isUnifiedMixingEnabled")));
@property (readonly) BOOL isUnifiedSDPEnabled __attribute__((swift_name("isUnifiedSDPEnabled")));
@property (readonly) BOOL isVideoEffectsEnabled __attribute__((swift_name("isVideoEffectsEnabled")));
@property (readonly) BOOL isVideoEffectsSettingsEnabled __attribute__((swift_name("isVideoEffectsSettingsEnabled")));
@property (readonly) BOOL isWhiteBoardAllowed __attribute__((swift_name("isWhiteBoardAllowed")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HostDetails")))
@interface MeetingsCoreHostDetails : MeetingsCoreBase
- (instancetype)initWithName:(NSString * _Nullable)name id:(NSString * _Nullable)id __attribute__((swift_name("init(name:id:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreHostDetails *)doCopyName:(NSString * _Nullable)name id:(NSString * _Nullable)id __attribute__((swift_name("doCopy(name:id:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaServerReachabilityReport")))
@interface MeetingsCoreMediaServerReachabilityReport : MeetingsCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) NSArray<MeetingsCoreMediaServerReachabilityReportMediaServerIPState *> *ipStates __attribute__((swift_name("ipStates")));
@property (readonly) MeetingsCoreMediaServerReachabilityReportStatus *testStatus __attribute__((swift_name("testStatus")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaServerReachabilityReport.MediaServerIPState")))
@interface MeetingsCoreMediaServerReachabilityReportMediaServerIPState : MeetingsCoreBase
- (instancetype)initWithPortName:(NSString *)portName portNumber:(NSString *)portNumber ipAddress:(NSString *)ipAddress status:(MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *)status __attribute__((swift_name("init(portName:portNumber:ipAddress:status:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreMediaServerReachabilityReportMediaServerIPState *)doCopyPortName:(NSString *)portName portNumber:(NSString *)portNumber ipAddress:(NSString *)ipAddress status:(MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *)status __attribute__((swift_name("doCopy(portName:portNumber:ipAddress:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *ipAddress __attribute__((swift_name("ipAddress")));
@property (readonly) NSString *portName __attribute__((swift_name("portName")));
@property (readonly) NSString *portNumber __attribute__((swift_name("portNumber")));
@property (readonly) MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *status __attribute__((swift_name("status")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaServerReachabilityReport.MediaServerIPStateStatus")))
@interface MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus : MeetingsCoreKotlinEnum<MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *allowed __attribute__((swift_name("allowed")));
@property (class, readonly) MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *blocked __attribute__((swift_name("blocked")));
+ (MeetingsCoreKotlinArray<MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreMediaServerReachabilityReportMediaServerIPStateStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaServerReachabilityReport.Status")))
@interface MeetingsCoreMediaServerReachabilityReportStatus : MeetingsCoreKotlinEnum<MeetingsCoreMediaServerReachabilityReportStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreMediaServerReachabilityReportStatus *initiated __attribute__((swift_name("initiated")));
@property (class, readonly) MeetingsCoreMediaServerReachabilityReportStatus *completed __attribute__((swift_name("completed")));
@property (class, readonly) MeetingsCoreMediaServerReachabilityReportStatus *notApplicable __attribute__((swift_name("notApplicable")));
+ (MeetingsCoreKotlinArray<MeetingsCoreMediaServerReachabilityReportStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreMediaServerReachabilityReportStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingConnectionMode")))
@interface MeetingsCoreMeetingConnectionMode : MeetingsCoreKotlinEnum<MeetingsCoreMeetingConnectionMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreMeetingConnectionModeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreMeetingConnectionMode *audio __attribute__((swift_name("audio")));
@property (class, readonly) MeetingsCoreMeetingConnectionMode *video __attribute__((swift_name("video")));
@property (class, readonly) MeetingsCoreMeetingConnectionMode *dataChannel __attribute__((swift_name("dataChannel")));
@property (class, readonly) MeetingsCoreMeetingConnectionMode *screenShare __attribute__((swift_name("screenShare")));
+ (MeetingsCoreKotlinArray<MeetingsCoreMeetingConnectionMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreMeetingConnectionMode *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingConnectionMode.Companion")))
@interface MeetingsCoreMeetingConnectionModeCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreMeetingConnectionModeCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreMeetingConnectionMode *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingDetails")))
@interface MeetingsCoreMeetingDetails : MeetingsCoreBase
- (instancetype)initWithTitle:(NSString * _Nullable)title isStreaming:(BOOL)isStreaming recording:(BOOL)recording layoutType:(MeetingsCoreInt * _Nullable)layoutType isActive:(BOOL)isActive type:(NSString * _Nullable)type speakerCount:(MeetingsCoreInt * _Nullable)speakerCount mainSpeakerCount:(MeetingsCoreInt * _Nullable)mainSpeakerCount memberType:(NSString * _Nullable)memberType creator:(MeetingsCoreCreatorDetails * _Nullable)creator mode:(NSString * _Nullable)mode waitingRoomEnabled:(BOOL)waitingRoomEnabled confId:(NSString * _Nullable)confId confKey:(NSString * _Nullable)confKey host:(MeetingsCoreHostDetails * _Nullable)host startTime:(MeetingsCoreLong * _Nullable)startTime memberConnectionMode:(NSString * _Nullable)memberConnectionMode skipWaitingRoom:(BOOL)skipWaitingRoom gridLayoutSize:(MeetingsCoreInt * _Nullable)gridLayoutSize __attribute__((swift_name("init(title:isStreaming:recording:layoutType:isActive:type:speakerCount:mainSpeakerCount:memberType:creator:mode:waitingRoomEnabled:confId:confKey:host:startTime:memberConnectionMode:skipWaitingRoom:gridLayoutSize:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreMeetingDetails *)doCopyTitle:(NSString * _Nullable)title isStreaming:(BOOL)isStreaming recording:(BOOL)recording layoutType:(MeetingsCoreInt * _Nullable)layoutType isActive:(BOOL)isActive type:(NSString * _Nullable)type speakerCount:(MeetingsCoreInt * _Nullable)speakerCount mainSpeakerCount:(MeetingsCoreInt * _Nullable)mainSpeakerCount memberType:(NSString * _Nullable)memberType creator:(MeetingsCoreCreatorDetails * _Nullable)creator mode:(NSString * _Nullable)mode waitingRoomEnabled:(BOOL)waitingRoomEnabled confId:(NSString * _Nullable)confId confKey:(NSString * _Nullable)confKey host:(MeetingsCoreHostDetails * _Nullable)host startTime:(MeetingsCoreLong * _Nullable)startTime memberConnectionMode:(NSString * _Nullable)memberConnectionMode skipWaitingRoom:(BOOL)skipWaitingRoom gridLayoutSize:(MeetingsCoreInt * _Nullable)gridLayoutSize __attribute__((swift_name("doCopy(title:isStreaming:recording:layoutType:isActive:type:speakerCount:mainSpeakerCount:memberType:creator:mode:waitingRoomEnabled:confId:confKey:host:startTime:memberConnectionMode:skipWaitingRoom:gridLayoutSize:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable confId __attribute__((swift_name("confId")));
@property (readonly) NSString * _Nullable confKey __attribute__((swift_name("confKey")));
@property (readonly) MeetingsCoreCreatorDetails * _Nullable creator __attribute__((swift_name("creator")));
@property (readonly) MeetingsCoreInt * _Nullable gridLayoutSize __attribute__((swift_name("gridLayoutSize")));
@property (readonly) MeetingsCoreHostDetails * _Nullable host __attribute__((swift_name("host")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isStreaming __attribute__((swift_name("isStreaming")));
@property (readonly) MeetingsCoreInt * _Nullable layoutType __attribute__((swift_name("layoutType")));
@property (readonly) MeetingsCoreInt * _Nullable mainSpeakerCount __attribute__((swift_name("mainSpeakerCount")));
@property (readonly) NSString * _Nullable memberConnectionMode __attribute__((swift_name("memberConnectionMode")));
@property (readonly) NSString * _Nullable memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable mode __attribute__((swift_name("mode")));
@property (readonly) BOOL recording __attribute__((swift_name("recording")));
@property (readonly) BOOL skipWaitingRoom __attribute__((swift_name("skipWaitingRoom")));
@property (readonly) MeetingsCoreInt * _Nullable speakerCount __attribute__((swift_name("speakerCount")));
@property (readonly) MeetingsCoreLong * _Nullable startTime __attribute__((swift_name("startTime")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) NSString * _Nullable type __attribute__((swift_name("type")));
@property (readonly) BOOL waitingRoomEnabled __attribute__((swift_name("waitingRoomEnabled")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingLayout")))
@interface MeetingsCoreMeetingLayout : MeetingsCoreKotlinEnum<MeetingsCoreMeetingLayout *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreMeetingLayoutCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreMeetingLayout *stage __attribute__((swift_name("stage")));
@property (class, readonly) MeetingsCoreMeetingLayout *grid __attribute__((swift_name("grid")));
+ (MeetingsCoreKotlinArray<MeetingsCoreMeetingLayout *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreMeetingLayout *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingLayout.Companion")))
@interface MeetingsCoreMeetingLayoutCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreMeetingLayoutCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreMeetingLayout *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberNotifierData")))
@interface MeetingsCoreMemberNotifierData : MeetingsCoreBase
- (instancetype)initWithRtcpUserId:(NSString *)rtcpUserId name:(NSString *)name isGuest:(BOOL)isGuest __attribute__((swift_name("init(rtcpUserId:name:isGuest:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreMemberNotifierData *)doCopyRtcpUserId:(NSString *)rtcpUserId name:(NSString *)name isGuest:(BOOL)isGuest __attribute__((swift_name("doCopy(rtcpUserId:name:isGuest:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isGuest __attribute__((swift_name("isGuest")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *rtcpUserId __attribute__((swift_name("rtcpUserId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberRole")))
@interface MeetingsCoreMemberRole : MeetingsCoreKotlinEnum<MeetingsCoreMemberRole *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreMemberRoleCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreMemberRole *primaryAdmin __attribute__((swift_name("primaryAdmin")));
@property (class, readonly) MeetingsCoreMemberRole *secondaryAdmin __attribute__((swift_name("secondaryAdmin")));
@property (class, readonly) MeetingsCoreMemberRole *participant __attribute__((swift_name("participant")));
@property (class, readonly) MeetingsCoreMemberRole *none __attribute__((swift_name("none")));
+ (MeetingsCoreKotlinArray<MeetingsCoreMemberRole *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreMemberRole *> *entries __attribute__((swift_name("entries")));
@property (readonly) MeetingsCoreUserRolesUserRoleDetails * _Nullable details __attribute__((swift_name("details")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberRole.Companion")))
@interface MeetingsCoreMemberRoleCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreMemberRoleCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreMemberRole *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberType")))
@interface MeetingsCoreMemberType : MeetingsCoreKotlinEnum<MeetingsCoreMemberType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreMemberTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreMemberType *active __attribute__((swift_name("active")));
@property (class, readonly) MeetingsCoreMemberType *silent __attribute__((swift_name("silent")));
+ (MeetingsCoreKotlinArray<MeetingsCoreMemberType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreMemberType *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberType.Companion")))
@interface MeetingsCoreMemberTypeCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreMemberTypeCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreMemberType *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PageDetail")))
@interface MeetingsCorePageDetail : MeetingsCoreBase
- (instancetype)initWithPageNumber:(int32_t)pageNumber members:(NSArray<MeetingsCoreRTCPMeetingsMember *> *)members __attribute__((swift_name("init(pageNumber:members:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCorePageDetail *)doCopyPageNumber:(int32_t)pageNumber members:(NSArray<MeetingsCoreRTCPMeetingsMember *> *)members __attribute__((swift_name("doCopy(pageNumber:members:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<MeetingsCoreRTCPMeetingsMember *> *members __attribute__((swift_name("members")));
@property (readonly) int32_t pageNumber __attribute__((swift_name("pageNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrimaryAdminAssignedNotifierData")))
@interface MeetingsCorePrimaryAdminAssignedNotifierData : MeetingsCoreBase
- (instancetype)initWithAssignedPrimaryAdmin:(MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *)assignedPrimaryAdmin previousPrimaryAdmin:(MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *)previousPrimaryAdmin __attribute__((swift_name("init(assignedPrimaryAdmin:previousPrimaryAdmin:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCorePrimaryAdminAssignedNotifierData *)doCopyAssignedPrimaryAdmin:(MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *)assignedPrimaryAdmin previousPrimaryAdmin:(MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *)previousPrimaryAdmin __attribute__((swift_name("doCopy(assignedPrimaryAdmin:previousPrimaryAdmin:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *assignedPrimaryAdmin __attribute__((swift_name("assignedPrimaryAdmin")));
@property (readonly) MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *previousPrimaryAdmin __attribute__((swift_name("previousPrimaryAdmin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrimaryAdminAssignedNotifierData.PrimaryAdminDetail")))
@interface MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail : MeetingsCoreBase
- (instancetype)initWithUserId:(NSString *)userId userName:(NSString *)userName role:(MeetingsCoreMemberRole *)role __attribute__((swift_name("init(userId:userName:role:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCorePrimaryAdminAssignedNotifierDataPrimaryAdminDetail *)doCopyUserId:(NSString *)userId userName:(NSString *)userName role:(MeetingsCoreMemberRole *)role __attribute__((swift_name("doCopy(userId:userName:role:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString *userName __attribute__((swift_name("userName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingRequest")))
@interface MeetingsCoreRTCPMeetingRequest : MeetingsCoreBase
- (instancetype)initWithRtcpUserId:(NSString *)rtcpUserId name:(NSString * _Nullable)name requestType:(MeetingsCoreRequestType *)requestType isGuest:(BOOL)isGuest __attribute__((swift_name("init(rtcpUserId:name:requestType:isGuest:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRTCPMeetingRequest *)doCopyRtcpUserId:(NSString *)rtcpUserId name:(NSString * _Nullable)name requestType:(MeetingsCoreRequestType *)requestType isGuest:(BOOL)isGuest __attribute__((swift_name("doCopy(rtcpUserId:name:requestType:isGuest:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isGuest __attribute__((swift_name("isGuest")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) MeetingsCoreRequestType *requestType __attribute__((swift_name("requestType")));
@property (readonly) NSString *rtcpUserId __attribute__((swift_name("rtcpUserId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingState")))
@interface MeetingsCoreRTCPMeetingState : MeetingsCoreKotlinEnum<MeetingsCoreRTCPMeetingState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreRTCPMeetingState *notStarted __attribute__((swift_name("notStarted")));
@property (class, readonly) MeetingsCoreRTCPMeetingState *active __attribute__((swift_name("active")));
@property (class, readonly) MeetingsCoreRTCPMeetingState *ended __attribute__((swift_name("ended")));
+ (MeetingsCoreKotlinArray<MeetingsCoreRTCPMeetingState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreRTCPMeetingState *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsConfigurations")))
@interface MeetingsCoreRTCPMeetingsConfigurations : MeetingsCoreBase
- (instancetype)initWithUserId:(NSString * _Nullable)userId username:(NSString * _Nullable)username cACL:(MeetingsCoreInt * _Nullable)cACL uACLName:(NSString * _Nullable)uACLName uACLValue:(MeetingsCoreInt * _Nullable)uACLValue userSkipWaitingRoom:(BOOL)userSkipWaitingRoom recordingEnabled:(BOOL)recordingEnabled __attribute__((swift_name("init(userId:username:cACL:uACLName:uACLValue:userSkipWaitingRoom:recordingEnabled:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRTCPMeetingsConfigurations *)doCopyUserId:(NSString * _Nullable)userId username:(NSString * _Nullable)username cACL:(MeetingsCoreInt * _Nullable)cACL uACLName:(NSString * _Nullable)uACLName uACLValue:(MeetingsCoreInt * _Nullable)uACLValue userSkipWaitingRoom:(BOOL)userSkipWaitingRoom recordingEnabled:(BOOL)recordingEnabled __attribute__((swift_name("doCopy(userId:username:cACL:uACLName:uACLValue:userSkipWaitingRoom:recordingEnabled:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MeetingsCoreKotlinx_coroutines_coreSharedFlow> conferenceACL __attribute__((swift_name("conferenceACL")));
@property (readonly) BOOL conferenceAssignSecondaryAdminRestricted __attribute__((swift_name("conferenceAssignSecondaryAdminRestricted")));
@property (readonly) BOOL conferenceDisableAudioAllRestricted __attribute__((swift_name("conferenceDisableAudioAllRestricted")));
@property (readonly) BOOL conferenceEnableAudioRestricted __attribute__((swift_name("conferenceEnableAudioRestricted")));
@property (readonly) BOOL conferenceEnableVideoRestricted __attribute__((swift_name("conferenceEnableVideoRestricted")));
@property (readonly) BOOL conferenceScreenShareBlocked __attribute__((swift_name("conferenceScreenShareBlocked")));
@property (readonly) BOOL conferenceScreenShareRestricted __attribute__((swift_name("conferenceScreenShareRestricted")));
@property (readonly) BOOL conferenceVideoRestricted __attribute__((swift_name("conferenceVideoRestricted")));
@property (readonly) BOOL conferenceWaitingRoomEnabled __attribute__((swift_name("conferenceWaitingRoomEnabled")));
@property (readonly) MeetingsCoreGlobalSettings * _Nullable globalSettings __attribute__((swift_name("globalSettings")));
@property (readonly) BOOL isApproveRejectJoinRequestActionAllowed __attribute__((swift_name("isApproveRejectJoinRequestActionAllowed")));
@property (readonly) BOOL isApproveRejectScreenShareRequestActionAllowed __attribute__((swift_name("isApproveRejectScreenShareRequestActionAllowed")));
@property (readonly) BOOL isApproveRejectSpeakerActionAllowed __attribute__((swift_name("isApproveRejectSpeakerActionAllowed")));
@property (readonly) BOOL isEndActionAllowed __attribute__((swift_name("isEndActionAllowed")));
@property (readonly) BOOL isEndScreenShareActionAllowed __attribute__((swift_name("isEndScreenShareActionAllowed")));
@property (readonly) BOOL isExcludeConferenceACL __attribute__((swift_name("isExcludeConferenceACL")));
@property (readonly) BOOL isJoinActionApproved __attribute__((swift_name("isJoinActionApproved")));
@property (readonly) BOOL isMuteUnMuteAllActionAllowed __attribute__((swift_name("isMuteUnMuteAllActionAllowed")));
@property (readonly) BOOL isOverrideRestrictScreenShare __attribute__((swift_name("isOverrideRestrictScreenShare")));
@property (readonly) BOOL isRecordingActionAllowed __attribute__((swift_name("isRecordingActionAllowed")));
@property (readonly) BOOL isRingActionAllowed __attribute__((swift_name("isRingActionAllowed")));
@property (readonly) BOOL isRingAllActionAllowed __attribute__((swift_name("isRingAllActionAllowed")));
@property (readonly) BOOL isScreenShareActionAllowed __attribute__((swift_name("isScreenShareActionAllowed")));
@property (readonly) BOOL isSendEmotionsActionAllowed __attribute__((swift_name("isSendEmotionsActionAllowed")));
@property (readonly) BOOL isSilentMember __attribute__((swift_name("isSilentMember")));
@property (readonly) BOOL isSkipWaitingRoomActionAllowed __attribute__((swift_name("isSkipWaitingRoomActionAllowed")));
@property (readonly) BOOL isSpotlightActionAllowed __attribute__((swift_name("isSpotlightActionAllowed")));
@property (readonly) BOOL isStartActionAllowed __attribute__((swift_name("isStartActionAllowed")));
@property (readonly) BOOL isSwitchMemberModeActionAllowed __attribute__((swift_name("isSwitchMemberModeActionAllowed")));
@property (readonly) BOOL isViewEmotionsActionAllowed __attribute__((swift_name("isViewEmotionsActionAllowed")));
@property (readonly) int64_t localTimeInMillis __attribute__((swift_name("localTimeInMillis")));
@property (readonly) BOOL recordingEnabled __attribute__((swift_name("recordingEnabled")));
@property (readonly) int64_t serverTimeInMillis __attribute__((swift_name("serverTimeInMillis")));
@property (readonly) MeetingsCoreUIPreference * _Nullable uiPreference __attribute__((swift_name("uiPreference")));
@property (readonly) id<MeetingsCoreKotlinx_coroutines_coreStateFlow> userACLName __attribute__((swift_name("userACLName")));
@property (readonly) id<MeetingsCoreKotlinx_coroutines_coreStateFlow> userACLValue __attribute__((swift_name("userACLValue")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@property BOOL userSkipWaitingRoom __attribute__((swift_name("userSkipWaitingRoom")));
@property (readonly) NSString * _Nullable username __attribute__((swift_name("username")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsMember")))
@interface MeetingsCoreRTCPMeetingsMember : MeetingsCoreBase
- (instancetype)initWithRtcpUserId:(NSString *)rtcpUserId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId meetingVideo:(MeetingsCoreRTCPMeetingVideo * _Nullable)meetingVideo ringing:(BOOL)ringing isInSpotlight:(BOOL)isInSpotlight isGuest:(BOOL)isGuest __attribute__((swift_name("init(rtcpUserId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:stageStreamId:gridStreamId:meetingVideo:ringing:isInSpotlight:isGuest:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRTCPMeetingsMember *)doCopyRtcpUserId:(NSString *)rtcpUserId name:(NSString * _Nullable)name viewType:(MeetingsCoreViewType *)viewType memberType:(MeetingsCoreMemberType *)memberType role:(MeetingsCoreMemberRole *)role audioEnabled:(BOOL)audioEnabled enableAudioRestricted:(BOOL)enableAudioRestricted videoEnabled:(BOOL)videoEnabled speaking:(BOOL)speaking stageStreamId:(NSString * _Nullable)stageStreamId gridStreamId:(NSString * _Nullable)gridStreamId meetingVideo:(MeetingsCoreRTCPMeetingVideo * _Nullable)meetingVideo ringing:(BOOL)ringing isInSpotlight:(BOOL)isInSpotlight isGuest:(BOOL)isGuest __attribute__((swift_name("doCopy(rtcpUserId:name:viewType:memberType:role:audioEnabled:enableAudioRestricted:videoEnabled:speaking:stageStreamId:gridStreamId:meetingVideo:ringing:isInSpotlight:isGuest:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL audioEnabled __attribute__((swift_name("audioEnabled")));
@property (readonly) BOOL enableAudioRestricted __attribute__((swift_name("enableAudioRestricted")));
@property (readonly) NSString * _Nullable gridStreamId __attribute__((swift_name("gridStreamId")));
@property (readonly) BOOL isGuest __attribute__((swift_name("isGuest")));
@property (readonly) BOOL isInSpotlight __attribute__((swift_name("isInSpotlight")));
@property MeetingsCoreRTCPMeetingVideo * _Nullable meetingVideo __attribute__((swift_name("meetingVideo")));
@property (readonly) MeetingsCoreMemberType *memberType __attribute__((swift_name("memberType")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property BOOL ringing __attribute__((swift_name("ringing")));
@property (readonly) MeetingsCoreMemberRole *role __attribute__((swift_name("role")));
@property (readonly) NSString *rtcpUserId __attribute__((swift_name("rtcpUserId")));
@property (readonly) BOOL speaking __attribute__((swift_name("speaking")));
@property (readonly) NSString * _Nullable stageStreamId __attribute__((swift_name("stageStreamId")));
@property (readonly) BOOL videoEnabled __attribute__((swift_name("videoEnabled")));
@property (readonly) MeetingsCoreViewType *viewType __attribute__((swift_name("viewType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsRemoteConfigs")))
@interface MeetingsCoreRTCPMeetingsRemoteConfigs : MeetingsCoreBase
- (instancetype)initWithBaseUrl:(NSString *)baseUrl appName:(NSString *)appName bundleId:(NSString *)bundleId meetingAction:(MeetingsCoreRTCPMeetingsRemoteConfigsAction *)meetingAction ipVersion:(NSString * _Nullable)ipVersion isCustomDomain:(BOOL)isCustomDomain usePolling:(BOOL)usePolling __attribute__((swift_name("init(baseUrl:appName:bundleId:meetingAction:ipVersion:isCustomDomain:usePolling:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRTCPMeetingsRemoteConfigs *)doCopyBaseUrl:(NSString *)baseUrl appName:(NSString *)appName bundleId:(NSString *)bundleId meetingAction:(MeetingsCoreRTCPMeetingsRemoteConfigsAction *)meetingAction ipVersion:(NSString * _Nullable)ipVersion isCustomDomain:(BOOL)isCustomDomain usePolling:(BOOL)usePolling __attribute__((swift_name("doCopy(baseUrl:appName:bundleId:meetingAction:ipVersion:isCustomDomain:usePolling:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *appName __attribute__((swift_name("appName")));
@property (readonly) NSString *baseUrl __attribute__((swift_name("baseUrl")));
@property (readonly) NSString *bundleId __attribute__((swift_name("bundleId")));
@property (readonly) NSString * _Nullable ipVersion __attribute__((swift_name("ipVersion")));
@property (readonly) BOOL isCustomDomain __attribute__((swift_name("isCustomDomain")));
@property (readonly) MeetingsCoreRTCPMeetingsRemoteConfigsAction *meetingAction __attribute__((swift_name("meetingAction")));
@property (readonly) BOOL usePolling __attribute__((swift_name("usePolling")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsRemoteConfigs.Action")))
@interface MeetingsCoreRTCPMeetingsRemoteConfigsAction : MeetingsCoreKotlinEnum<MeetingsCoreRTCPMeetingsRemoteConfigsAction *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreRTCPMeetingsRemoteConfigsAction *start __attribute__((swift_name("start")));
@property (class, readonly) MeetingsCoreRTCPMeetingsRemoteConfigsAction *join __attribute__((swift_name("join")));
+ (MeetingsCoreKotlinArray<MeetingsCoreRTCPMeetingsRemoteConfigsAction *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreRTCPMeetingsRemoteConfigsAction *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsState")))
@interface MeetingsCoreRTCPMeetingsState : MeetingsCoreKotlinEnum<MeetingsCoreRTCPMeetingsState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreRTCPMeetingsState *none __attribute__((swift_name("none")));
@property (class, readonly) MeetingsCoreRTCPMeetingsState *waiting __attribute__((swift_name("waiting")));
@property (class, readonly) MeetingsCoreRTCPMeetingsState *connecting __attribute__((swift_name("connecting")));
@property (class, readonly) MeetingsCoreRTCPMeetingsState *connected __attribute__((swift_name("connected")));
+ (MeetingsCoreKotlinArray<MeetingsCoreRTCPMeetingsState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreRTCPMeetingsState *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPWMSConfiguration")))
@interface MeetingsCoreRTCPWMSConfiguration : MeetingsCoreBase
- (instancetype)initWithRegisterWMSSession:(void (^)(NSString *, NSString *, NSString *, NSString *, MeetingsCoreInt *, NSString *, MeetingsCoreMutableDictionary<NSString *, NSString *> *, MeetingsCoreKotlinUnit *(^)(NSString *, NSString *), MeetingsCoreKotlinUnit *(^)(NSString *)))registerWMSSession disconnectWMSSession:(void (^)(NSString *))disconnectWMSSession isWMSSessionConnected:(MeetingsCoreBoolean *(^)(NSString *))isWMSSessionConnected wmsMessageDispatcher:(void (^)(NSString *, NSString *, NSDictionary<NSString *, NSString *> *, NSString *))wmsMessageDispatcher sessionId:(NSString * _Nullable)sessionId isCustomDomain:(BOOL)isCustomDomain __attribute__((swift_name("init(registerWMSSession:disconnectWMSSession:isWMSSessionConnected:wmsMessageDispatcher:sessionId:isCustomDomain:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRTCPWMSConfiguration *)doCopyRegisterWMSSession:(void (^)(NSString *, NSString *, NSString *, NSString *, MeetingsCoreInt *, NSString *, MeetingsCoreMutableDictionary<NSString *, NSString *> *, MeetingsCoreKotlinUnit *(^)(NSString *, NSString *), MeetingsCoreKotlinUnit *(^)(NSString *)))registerWMSSession disconnectWMSSession:(void (^)(NSString *))disconnectWMSSession isWMSSessionConnected:(MeetingsCoreBoolean *(^)(NSString *))isWMSSessionConnected wmsMessageDispatcher:(void (^)(NSString *, NSString *, NSDictionary<NSString *, NSString *> *, NSString *))wmsMessageDispatcher sessionId:(NSString * _Nullable)sessionId isCustomDomain:(BOOL)isCustomDomain __attribute__((swift_name("doCopy(registerWMSSession:disconnectWMSSession:isWMSSessionConnected:wmsMessageDispatcher:sessionId:isCustomDomain:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^disconnectWMSSession)(NSString *) __attribute__((swift_name("disconnectWMSSession")));
@property (readonly) MeetingsCoreBoolean *(^isWMSSessionConnected)(NSString *) __attribute__((swift_name("isWMSSessionConnected")));
@property (readonly) void (^registerWMSSession)(NSString *, NSString *, NSString *, NSString *, MeetingsCoreInt *, NSString *, MeetingsCoreMutableDictionary<NSString *, NSString *> *, MeetingsCoreKotlinUnit *(^)(NSString *, NSString *), MeetingsCoreKotlinUnit *(^)(NSString *)) __attribute__((swift_name("registerWMSSession")));
@property (readonly) void (^wmsMessageDispatcher)(NSString *, NSString *, NSDictionary<NSString *, NSString *> *, NSString *) __attribute__((swift_name("wmsMessageDispatcher")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordingNotifierData")))
@interface MeetingsCoreRecordingNotifierData : MeetingsCoreBase
- (instancetype)initWithStatus:(MeetingsCoreRecordingNotifierDataRecordingAction *)status actionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName __attribute__((swift_name("init(status:actionUserId:actionUserName:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRecordingNotifierData *)doCopyStatus:(MeetingsCoreRecordingNotifierDataRecordingAction *)status actionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName __attribute__((swift_name("doCopy(status:actionUserId:actionUserName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *actionUserId __attribute__((swift_name("actionUserId")));
@property (readonly) NSString *actionUserName __attribute__((swift_name("actionUserName")));
@property (readonly) MeetingsCoreRecordingNotifierDataRecordingAction *status __attribute__((swift_name("status")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordingNotifierData.RecordingAction")))
@interface MeetingsCoreRecordingNotifierDataRecordingAction : MeetingsCoreKotlinEnum<MeetingsCoreRecordingNotifierDataRecordingAction *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreRecordingNotifierDataRecordingAction *started __attribute__((swift_name("started")));
@property (class, readonly) MeetingsCoreRecordingNotifierDataRecordingAction *stopped __attribute__((swift_name("stopped")));
@property (class, readonly) MeetingsCoreRecordingNotifierDataRecordingAction *autoStarted __attribute__((swift_name("autoStarted")));
+ (MeetingsCoreKotlinArray<MeetingsCoreRecordingNotifierDataRecordingAction *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreRecordingNotifierDataRecordingAction *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemovedMemberNotifierData")))
@interface MeetingsCoreRemovedMemberNotifierData : MeetingsCoreBase
- (instancetype)initWithActionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("init(actionUserId:actionUserName:primaryAdminId:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRemovedMemberNotifierData *)doCopyActionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("doCopy(actionUserId:actionUserName:primaryAdminId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *actionUserId __attribute__((swift_name("actionUserId")));
@property (readonly) NSString *actionUserName __attribute__((swift_name("actionUserName")));
@property (readonly) NSString *primaryAdminId __attribute__((swift_name("primaryAdminId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestType")))
@interface MeetingsCoreRequestType : MeetingsCoreKotlinEnum<MeetingsCoreRequestType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreRequestTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreRequestType *yetToJoinWaitingRoom __attribute__((swift_name("yetToJoinWaitingRoom")));
@property (class, readonly) MeetingsCoreRequestType *waitingRoom __attribute__((swift_name("waitingRoom")));
@property (class, readonly) MeetingsCoreRequestType *rejectedWaitingRoom __attribute__((swift_name("rejectedWaitingRoom")));
@property (class, readonly) MeetingsCoreRequestType *approvedWaitingRoom __attribute__((swift_name("approvedWaitingRoom")));
@property (class, readonly) MeetingsCoreRequestType *speak __attribute__((swift_name("speak")));
@property (class, readonly) MeetingsCoreRequestType *none __attribute__((swift_name("none")));
+ (MeetingsCoreKotlinArray<MeetingsCoreRequestType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreRequestType *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestType.Companion")))
@interface MeetingsCoreRequestTypeCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRequestTypeCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreRequestType *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecondaryAdminAssignedRemovedNotifierData")))
@interface MeetingsCoreSecondaryAdminAssignedRemovedNotifierData : MeetingsCoreBase
- (instancetype)initWithAssignedSecondaryAdmins:(NSArray<MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *> *)assignedSecondaryAdmins removedSecondaryAdmins:(NSArray<MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *> *)removedSecondaryAdmins actionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("init(assignedSecondaryAdmins:removedSecondaryAdmins:actionUserId:actionUserName:primaryAdminId:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreSecondaryAdminAssignedRemovedNotifierData *)doCopyAssignedSecondaryAdmins:(NSArray<MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *> *)assignedSecondaryAdmins removedSecondaryAdmins:(NSArray<MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *> *)removedSecondaryAdmins actionUserId:(NSString *)actionUserId actionUserName:(NSString *)actionUserName primaryAdminId:(NSString *)primaryAdminId __attribute__((swift_name("doCopy(assignedSecondaryAdmins:removedSecondaryAdmins:actionUserId:actionUserName:primaryAdminId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *actionUserId __attribute__((swift_name("actionUserId")));
@property (readonly) NSString *actionUserName __attribute__((swift_name("actionUserName")));
@property (readonly) NSArray<MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *> *assignedSecondaryAdmins __attribute__((swift_name("assignedSecondaryAdmins")));
@property (readonly) NSString *primaryAdminId __attribute__((swift_name("primaryAdminId")));
@property (readonly) NSArray<MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *> *removedSecondaryAdmins __attribute__((swift_name("removedSecondaryAdmins")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecondaryAdminAssignedRemovedNotifierData.SecondaryAdminDetail")))
@interface MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail : MeetingsCoreBase
- (instancetype)initWithUserId:(NSString *)userId userName:(NSString *)userName __attribute__((swift_name("init(userId:userName:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreSecondaryAdminAssignedRemovedNotifierDataSecondaryAdminDetail *)doCopyUserId:(NSString *)userId userName:(NSString *)userName __attribute__((swift_name("doCopy(userId:userName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@property (readonly) NSString *userName __attribute__((swift_name("userName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UIPreference")))
@interface MeetingsCoreUIPreference : MeetingsCoreBase
- (instancetype)initWithShowBtnPreviewClose:(BOOL)showBtnPreviewClose showBtnScreenShare:(BOOL)showBtnScreenShare showBtnMuteAudio:(BOOL)showBtnMuteAudio showOptionMakeHost:(BOOL)showOptionMakeHost showTitleInConference:(BOOL)showTitleInConference showOptionPinVideo:(BOOL)showOptionPinVideo showBtnMinimize:(BOOL)showBtnMinimize showBtnStageView:(BOOL)showBtnStageView showBtnDisplayNameInPreview:(BOOL)showBtnDisplayNameInPreview showEndBtn:(BOOL)showEndBtn showBtnMuteVideo:(BOOL)showBtnMuteVideo showBtnChat:(BOOL)showBtnChat showBtnStartStreaming:(BOOL)showBtnStartStreaming allowAssignAndLeave:(BOOL)allowAssignAndLeave showBtnSettings:(BOOL)showBtnSettings showBtnGridView:(BOOL)showBtnGridView showOptionMakeCoHost:(BOOL)showOptionMakeCoHost editDisplayNameInPreview:(BOOL)editDisplayNameInPreview showBackBtn:(BOOL)showBackBtn showOptionSpotlight:(BOOL)showOptionSpotlight showBtnStartRecording:(BOOL)showBtnStartRecording showAudioOutputDropdown:(BOOL)showAudioOutputDropdown showUserOptionMute:(BOOL)showUserOptionMute showBtnParticipants:(BOOL)showBtnParticipants showActiveSpeakerGridView:(BOOL)showActiveSpeakerGridView showOptionUpdateRole:(BOOL)showOptionUpdateRole showSmileyBtn:(BOOL)showSmileyBtn showMinimizedViewByDefault:(BOOL)showMinimizedViewByDefault showTownHallOption:(BOOL)showTownHallOption showInviteUserOption:(BOOL)showInviteUserOption showRemoveUserOption:(BOOL)showRemoveUserOption showYetToJoinGuest:(BOOL)showYetToJoinGuest showContainerUserOption:(BOOL)showContainerUserOption showRingBtn:(BOOL)showRingBtn __attribute__((swift_name("init(showBtnPreviewClose:showBtnScreenShare:showBtnMuteAudio:showOptionMakeHost:showTitleInConference:showOptionPinVideo:showBtnMinimize:showBtnStageView:showBtnDisplayNameInPreview:showEndBtn:showBtnMuteVideo:showBtnChat:showBtnStartStreaming:allowAssignAndLeave:showBtnSettings:showBtnGridView:showOptionMakeCoHost:editDisplayNameInPreview:showBackBtn:showOptionSpotlight:showBtnStartRecording:showAudioOutputDropdown:showUserOptionMute:showBtnParticipants:showActiveSpeakerGridView:showOptionUpdateRole:showSmileyBtn:showMinimizedViewByDefault:showTownHallOption:showInviteUserOption:showRemoveUserOption:showYetToJoinGuest:showContainerUserOption:showRingBtn:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreUIPreference *)doCopyShowBtnPreviewClose:(BOOL)showBtnPreviewClose showBtnScreenShare:(BOOL)showBtnScreenShare showBtnMuteAudio:(BOOL)showBtnMuteAudio showOptionMakeHost:(BOOL)showOptionMakeHost showTitleInConference:(BOOL)showTitleInConference showOptionPinVideo:(BOOL)showOptionPinVideo showBtnMinimize:(BOOL)showBtnMinimize showBtnStageView:(BOOL)showBtnStageView showBtnDisplayNameInPreview:(BOOL)showBtnDisplayNameInPreview showEndBtn:(BOOL)showEndBtn showBtnMuteVideo:(BOOL)showBtnMuteVideo showBtnChat:(BOOL)showBtnChat showBtnStartStreaming:(BOOL)showBtnStartStreaming allowAssignAndLeave:(BOOL)allowAssignAndLeave showBtnSettings:(BOOL)showBtnSettings showBtnGridView:(BOOL)showBtnGridView showOptionMakeCoHost:(BOOL)showOptionMakeCoHost editDisplayNameInPreview:(BOOL)editDisplayNameInPreview showBackBtn:(BOOL)showBackBtn showOptionSpotlight:(BOOL)showOptionSpotlight showBtnStartRecording:(BOOL)showBtnStartRecording showAudioOutputDropdown:(BOOL)showAudioOutputDropdown showUserOptionMute:(BOOL)showUserOptionMute showBtnParticipants:(BOOL)showBtnParticipants showActiveSpeakerGridView:(BOOL)showActiveSpeakerGridView showOptionUpdateRole:(BOOL)showOptionUpdateRole showSmileyBtn:(BOOL)showSmileyBtn showMinimizedViewByDefault:(BOOL)showMinimizedViewByDefault showTownHallOption:(BOOL)showTownHallOption showInviteUserOption:(BOOL)showInviteUserOption showRemoveUserOption:(BOOL)showRemoveUserOption showYetToJoinGuest:(BOOL)showYetToJoinGuest showContainerUserOption:(BOOL)showContainerUserOption showRingBtn:(BOOL)showRingBtn __attribute__((swift_name("doCopy(showBtnPreviewClose:showBtnScreenShare:showBtnMuteAudio:showOptionMakeHost:showTitleInConference:showOptionPinVideo:showBtnMinimize:showBtnStageView:showBtnDisplayNameInPreview:showEndBtn:showBtnMuteVideo:showBtnChat:showBtnStartStreaming:allowAssignAndLeave:showBtnSettings:showBtnGridView:showOptionMakeCoHost:editDisplayNameInPreview:showBackBtn:showOptionSpotlight:showBtnStartRecording:showAudioOutputDropdown:showUserOptionMute:showBtnParticipants:showActiveSpeakerGridView:showOptionUpdateRole:showSmileyBtn:showMinimizedViewByDefault:showTownHallOption:showInviteUserOption:showRemoveUserOption:showYetToJoinGuest:showContainerUserOption:showRingBtn:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowAssignAndLeave __attribute__((swift_name("allowAssignAndLeave")));
@property (readonly) BOOL editDisplayNameInPreview __attribute__((swift_name("editDisplayNameInPreview")));
@property (readonly) BOOL showActiveSpeakerGridView __attribute__((swift_name("showActiveSpeakerGridView")));
@property (readonly) BOOL showAudioOutputDropdown __attribute__((swift_name("showAudioOutputDropdown")));
@property (readonly) BOOL showBackBtn __attribute__((swift_name("showBackBtn")));
@property (readonly) BOOL showBtnChat __attribute__((swift_name("showBtnChat")));
@property (readonly) BOOL showBtnDisplayNameInPreview __attribute__((swift_name("showBtnDisplayNameInPreview")));
@property (readonly) BOOL showBtnGridView __attribute__((swift_name("showBtnGridView")));
@property (readonly) BOOL showBtnMinimize __attribute__((swift_name("showBtnMinimize")));
@property (readonly) BOOL showBtnMuteAudio __attribute__((swift_name("showBtnMuteAudio")));
@property (readonly) BOOL showBtnMuteVideo __attribute__((swift_name("showBtnMuteVideo")));
@property (readonly) BOOL showBtnParticipants __attribute__((swift_name("showBtnParticipants")));
@property (readonly) BOOL showBtnPreviewClose __attribute__((swift_name("showBtnPreviewClose")));
@property (readonly) BOOL showBtnScreenShare __attribute__((swift_name("showBtnScreenShare")));
@property (readonly) BOOL showBtnSettings __attribute__((swift_name("showBtnSettings")));
@property (readonly) BOOL showBtnStageView __attribute__((swift_name("showBtnStageView")));
@property (readonly) BOOL showBtnStartRecording __attribute__((swift_name("showBtnStartRecording")));
@property (readonly) BOOL showBtnStartStreaming __attribute__((swift_name("showBtnStartStreaming")));
@property (readonly) BOOL showContainerUserOption __attribute__((swift_name("showContainerUserOption")));
@property (readonly) BOOL showEndBtn __attribute__((swift_name("showEndBtn")));
@property (readonly) BOOL showInviteUserOption __attribute__((swift_name("showInviteUserOption")));
@property (readonly) BOOL showMinimizedViewByDefault __attribute__((swift_name("showMinimizedViewByDefault")));
@property (readonly) BOOL showOptionMakeCoHost __attribute__((swift_name("showOptionMakeCoHost")));
@property (readonly) BOOL showOptionMakeHost __attribute__((swift_name("showOptionMakeHost")));
@property (readonly) BOOL showOptionPinVideo __attribute__((swift_name("showOptionPinVideo")));
@property (readonly) BOOL showOptionSpotlight __attribute__((swift_name("showOptionSpotlight")));
@property (readonly) BOOL showOptionUpdateRole __attribute__((swift_name("showOptionUpdateRole")));
@property (readonly) BOOL showRemoveUserOption __attribute__((swift_name("showRemoveUserOption")));
@property (readonly) BOOL showRingBtn __attribute__((swift_name("showRingBtn")));
@property (readonly) BOOL showSmileyBtn __attribute__((swift_name("showSmileyBtn")));
@property (readonly) BOOL showTitleInConference __attribute__((swift_name("showTitleInConference")));
@property (readonly) BOOL showTownHallOption __attribute__((swift_name("showTownHallOption")));
@property (readonly) BOOL showUserOptionMute __attribute__((swift_name("showUserOptionMute")));
@property (readonly) BOOL showYetToJoinGuest __attribute__((swift_name("showYetToJoinGuest")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserACL")))
@interface MeetingsCoreUserACL : MeetingsCoreKotlinEnum<MeetingsCoreUserACL *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreUserACLCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreUserACL *start __attribute__((swift_name("start")));
@property (class, readonly) MeetingsCoreUserACL *end __attribute__((swift_name("end")));
@property (class, readonly) MeetingsCoreUserACL *recording __attribute__((swift_name("recording")));
@property (class, readonly) MeetingsCoreUserACL *approveRejectSpeaker __attribute__((swift_name("approveRejectSpeaker")));
@property (class, readonly) MeetingsCoreUserACL *muteUnMuteAll __attribute__((swift_name("muteUnMuteAll")));
@property (class, readonly) MeetingsCoreUserACL *ring __attribute__((swift_name("ring")));
@property (class, readonly) MeetingsCoreUserACL *ringAll __attribute__((swift_name("ringAll")));
@property (class, readonly) MeetingsCoreUserACL *kickOut __attribute__((swift_name("kickOut")));
@property (class, readonly) MeetingsCoreUserACL *screenShare __attribute__((swift_name("screenShare")));
@property (class, readonly) MeetingsCoreUserACL *endParticipantScreenShare __attribute__((swift_name("endParticipantScreenShare")));
@property (class, readonly) MeetingsCoreUserACL *viewChat __attribute__((swift_name("viewChat")));
@property (class, readonly) MeetingsCoreUserACL *sendChatMsg __attribute__((swift_name("sendChatMsg")));
@property (class, readonly) MeetingsCoreUserACL *viewEmotions __attribute__((swift_name("viewEmotions")));
@property (class, readonly) MeetingsCoreUserACL *sendEmotions __attribute__((swift_name("sendEmotions")));
@property (class, readonly) MeetingsCoreUserACL *silentParticipant __attribute__((swift_name("silentParticipant")));
@property (class, readonly) MeetingsCoreUserACL *livestreamStudio __attribute__((swift_name("livestreamStudio")));
@property (class, readonly) MeetingsCoreUserACL *skipWaitingRoom __attribute__((swift_name("skipWaitingRoom")));
@property (class, readonly) MeetingsCoreUserACL *approveRejectJoinRequest __attribute__((swift_name("approveRejectJoinRequest")));
@property (class, readonly) MeetingsCoreUserACL *joinApproved __attribute__((swift_name("joinApproved")));
@property (class, readonly) MeetingsCoreUserACL *switchMemberMode __attribute__((swift_name("switchMemberMode")));
@property (class, readonly) MeetingsCoreUserACL *spotlight __attribute__((swift_name("spotlight")));
@property (class, readonly) MeetingsCoreUserACL *excludeConferenceAcl __attribute__((swift_name("excludeConferenceAcl")));
@property (class, readonly) MeetingsCoreUserACL *overrideRestrictShare __attribute__((swift_name("overrideRestrictShare")));
@property (class, readonly) MeetingsCoreUserACL *approveRejectShareRequest __attribute__((swift_name("approveRejectShareRequest")));
+ (MeetingsCoreKotlinArray<MeetingsCoreUserACL *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreUserACL *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserACL.Companion")))
@interface MeetingsCoreUserACLCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreUserACLCompanion *shared __attribute__((swift_name("shared")));
- (BOOL)isApproveRejectJoinRequestActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isApproveRejectJoinRequestActionAllowed(aclValue:)")));
- (BOOL)isApproveRejectScreenShareRequestActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isApproveRejectScreenShareRequestActionAllowed(aclValue:)")));
- (BOOL)isApproveRejectSpeakerActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isApproveRejectSpeakerActionAllowed(aclValue:)")));
- (BOOL)isEndActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isEndActionAllowed(aclValue:)")));
- (BOOL)isEndScreenShareActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isEndScreenShareActionAllowed(aclValue:)")));
- (BOOL)isExcludeConferenceACLAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isExcludeConferenceACL(aclValue:)")));
- (BOOL)isJoinActionApprovedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isJoinActionApproved(aclValue:)")));
- (BOOL)isMuteUnMuteAllActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isMuteUnMuteAllActionAllowed(aclValue:)")));
- (BOOL)isOverrideRestrictScreenShareAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isOverrideRestrictScreenShare(aclValue:)")));
- (BOOL)isRecordingActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isRecordingActionAllowed(aclValue:)")));
- (BOOL)isRingActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isRingActionAllowed(aclValue:)")));
- (BOOL)isRingAllActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isRingAllActionAllowed(aclValue:)")));
- (BOOL)isScreenShareActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isScreenShareActionAllowed(aclValue:)")));
- (BOOL)isSendEmotionsActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isSendEmotionsActionAllowed(aclValue:)")));
- (BOOL)isSilentMemberAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isSilentMember(aclValue:)")));
- (BOOL)isSkipWaitingRoomActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isSkipWaitingRoomActionAllowed(aclValue:)")));
- (BOOL)isSpotlightActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isSpotlightActionAllowed(aclValue:)")));
- (BOOL)isStartActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isStartActionAllowed(aclValue:)")));
- (BOOL)isSwitchMemberModeActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isSwitchMemberModeActionAllowed(aclValue:)")));
- (BOOL)isViewEmotionsActionAllowedAclValue:(MeetingsCoreInt * _Nullable)aclValue __attribute__((swift_name("isViewEmotionsActionAllowed(aclValue:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserRoles")))
@interface MeetingsCoreUserRoles : MeetingsCoreBase
- (instancetype)initWithCallPrimaryAdmin:(MeetingsCoreUserRolesUserRoleDetails * _Nullable)callPrimaryAdmin callSecondaryAdmin:(MeetingsCoreUserRolesUserRoleDetails * _Nullable)callSecondaryAdmin callParticipant:(MeetingsCoreUserRolesUserRoleDetails * _Nullable)callParticipant __attribute__((swift_name("init(callPrimaryAdmin:callSecondaryAdmin:callParticipant:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreUserRoles *)doCopyCallPrimaryAdmin:(MeetingsCoreUserRolesUserRoleDetails * _Nullable)callPrimaryAdmin callSecondaryAdmin:(MeetingsCoreUserRolesUserRoleDetails * _Nullable)callSecondaryAdmin callParticipant:(MeetingsCoreUserRolesUserRoleDetails * _Nullable)callParticipant __attribute__((swift_name("doCopy(callPrimaryAdmin:callSecondaryAdmin:callParticipant:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MeetingsCoreUserRolesUserRoleDetails * _Nullable callParticipant __attribute__((swift_name("callParticipant")));
@property (readonly) MeetingsCoreUserRolesUserRoleDetails * _Nullable callPrimaryAdmin __attribute__((swift_name("callPrimaryAdmin")));
@property (readonly) MeetingsCoreUserRolesUserRoleDetails * _Nullable callSecondaryAdmin __attribute__((swift_name("callSecondaryAdmin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserRoles.UserRoleDetails")))
@interface MeetingsCoreUserRolesUserRoleDetails : MeetingsCoreBase
- (instancetype)initWithResourceKey:(NSString * _Nullable)resourceKey name:(NSString * _Nullable)name collectiveName:(NSString * _Nullable)collectiveName __attribute__((swift_name("init(resourceKey:name:collectiveName:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreUserRolesUserRoleDetails *)doCopyResourceKey:(NSString * _Nullable)resourceKey name:(NSString * _Nullable)name collectiveName:(NSString * _Nullable)collectiveName __attribute__((swift_name("doCopy(resourceKey:name:collectiveName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable collectiveName __attribute__((swift_name("collectiveName")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable resourceKey __attribute__((swift_name("resourceKey")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VideoCaptureSpec")))
@interface MeetingsCoreVideoCaptureSpec : MeetingsCoreBase
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height fps:(int32_t)fps __attribute__((swift_name("init(width:height:fps:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreVideoCaptureSpec *)doCopyWidth:(int32_t)width height:(int32_t)height fps:(int32_t)fps __attribute__((swift_name("doCopy(width:height:fps:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t fps __attribute__((swift_name("fps")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ViewType")))
@interface MeetingsCoreViewType : MeetingsCoreKotlinEnum<MeetingsCoreViewType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MeetingsCoreViewTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MeetingsCoreViewType *user __attribute__((swift_name("user")));
@property (class, readonly) MeetingsCoreViewType *screenShare __attribute__((swift_name("screenShare")));
+ (MeetingsCoreKotlinArray<MeetingsCoreViewType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreViewType *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ViewType.Companion")))
@interface MeetingsCoreViewTypeCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreViewTypeCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreViewType *)actualValueOfValue:(NSString *)value __attribute__((swift_name("actualValueOf(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WaitingRoomStatus")))
@interface MeetingsCoreWaitingRoomStatus : MeetingsCoreKotlinEnum<MeetingsCoreWaitingRoomStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreWaitingRoomStatus *yetToRequest __attribute__((swift_name("yetToRequest")));
@property (class, readonly) MeetingsCoreWaitingRoomStatus *pending __attribute__((swift_name("pending")));
@property (class, readonly) MeetingsCoreWaitingRoomStatus *allowed __attribute__((swift_name("allowed")));
@property (class, readonly) MeetingsCoreWaitingRoomStatus *rejected __attribute__((swift_name("rejected")));
+ (MeetingsCoreKotlinArray<MeetingsCoreWaitingRoomStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreWaitingRoomStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingVideo")))
@interface MeetingsCoreRTCPMeetingVideo : MeetingsCoreBase
- (instancetype)initWithVideoTrack:(MeetingsCoreRtcp_coreVideoStreamTrack *)videoTrack videoSinkDetails:(MeetingsCoreRtcp_coreVideoSinkDetails *)videoSinkDetails videoSink:(NSObject *)videoSink isMobileScreenShare:(BOOL)isMobileScreenShare mirrorVideo:(BOOL)mirrorVideo __attribute__((swift_name("init(videoTrack:videoSinkDetails:videoSink:isMobileScreenShare:mirrorVideo:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreRTCPMeetingVideo *)doCopyVideoTrack:(MeetingsCoreRtcp_coreVideoStreamTrack *)videoTrack videoSinkDetails:(MeetingsCoreRtcp_coreVideoSinkDetails *)videoSinkDetails videoSink:(NSObject *)videoSink isMobileScreenShare:(BOOL)isMobileScreenShare mirrorVideo:(BOOL)mirrorVideo __attribute__((swift_name("doCopy(videoTrack:videoSinkDetails:videoSink:isMobileScreenShare:mirrorVideo:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isMobileScreenShare __attribute__((swift_name("isMobileScreenShare")));
@property (readonly) BOOL mirrorVideo __attribute__((swift_name("mirrorVideo")));
@property (readonly) NSObject *videoSink __attribute__((swift_name("videoSink")));
@property (readonly) MeetingsCoreRtcp_coreVideoSinkDetails *videoSinkDetails __attribute__((swift_name("videoSinkDetails")));
@property (readonly) MeetingsCoreRtcp_coreVideoStreamTrack *videoTrack __attribute__((swift_name("videoTrack")));
@end

@interface MeetingsCoreRTCPMeetingsClientResultError (Extensions)
- (MeetingsCoreRTCPMeetingsClientException *)toRTCPMeetingsClientException __attribute__((swift_name("toRTCPMeetingsClientException()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExtensionsKt")))
@interface MeetingsCoreExtensionsKt : MeetingsCoreBase
+ (NSString *)getOriginalUserIdFromRTCPUserId:(NSString *)receiver __attribute__((swift_name("getOriginalUserIdFromRTCPUserId(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformKt")))
@interface MeetingsCorePlatformKt : MeetingsCoreBase
+ (id<MeetingsCorePlatform>)getPlatform __attribute__((swift_name("getPlatform()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsClientResultKt")))
@interface MeetingsCoreRTCPMeetingsClientResultKt : MeetingsCoreBase
+ (MeetingsCoreRTCPMeetingsClientResult<id> *)buildRTCPMeetingsClientResultBlock:(id _Nullable (^)(void))block __attribute__((swift_name("buildRTCPMeetingsClientResult(block:)")));
+ (MeetingsCoreRTCPMeetingsClientResult<id> *)toRTCPMeetingsClientResult:(id _Nullable)receiver __attribute__((swift_name("toRTCPMeetingsClientResult(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RTCPMeetingsResponseKt")))
@interface MeetingsCoreRTCPMeetingsResponseKt : MeetingsCoreBase
@property (class, readonly) MeetingsCoreKotlinx_serialization_jsonJson *RTCPJson __attribute__((swift_name("RTCPJson")));
@end

__attribute__((swift_name("RuntimeColumnAdapter")))
@protocol MeetingsCoreRuntimeColumnAdapter
@required
- (id)decodeDatabaseValue:(id _Nullable)databaseValue __attribute__((swift_name("decode(databaseValue:)")));
- (id _Nullable)encodeValue:(id)value __attribute__((swift_name("encode(value:)")));
@end

__attribute__((swift_name("RuntimeCloseable")))
@protocol MeetingsCoreRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol MeetingsCoreRuntimeSqlDriver <MeetingsCoreRuntimeCloseable>
@required
- (void)addListenerQueryKeys:(MeetingsCoreKotlinArray<NSString *> *)queryKeys listener:(id<MeetingsCoreRuntimeQueryListener>)listener __attribute__((swift_name("addListener(queryKeys:listener:)")));
- (MeetingsCoreRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (id<MeetingsCoreRuntimeQueryResult>)executeIdentifier:(MeetingsCoreInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<MeetingsCoreRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<MeetingsCoreRuntimeQueryResult>)executeQueryIdentifier:(MeetingsCoreInt * _Nullable)identifier sql:(NSString *)sql mapper:(id<MeetingsCoreRuntimeQueryResult> (^)(id<MeetingsCoreRuntimeSqlCursor>))mapper parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<MeetingsCoreRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:mapper:parameters:binders:)")));
- (id<MeetingsCoreRuntimeQueryResult>)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
- (void)notifyListenersQueryKeys:(MeetingsCoreKotlinArray<NSString *> *)queryKeys __attribute__((swift_name("notifyListeners(queryKeys:)")));
- (void)removeListenerQueryKeys:(MeetingsCoreKotlinArray<NSString *> *)queryKeys listener:(id<MeetingsCoreRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(queryKeys:listener:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface MeetingsCoreKotlinUnit : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol MeetingsCoreRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface MeetingsCoreRuntimeTransacterTransaction : MeetingsCoreBase <MeetingsCoreRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<MeetingsCoreRuntimeQueryResult>)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) MeetingsCoreRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol MeetingsCoreRuntimeTransactionWithoutReturn <MeetingsCoreRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<MeetingsCoreRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol MeetingsCoreRuntimeTransactionWithReturn <MeetingsCoreRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<MeetingsCoreRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end

__attribute__((swift_name("RuntimeExecutableQuery")))
@interface MeetingsCoreRuntimeExecutableQuery<__covariant RowType> : MeetingsCoreBase
- (instancetype)initWithMapper:(RowType (^)(id<MeetingsCoreRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (id<MeetingsCoreRuntimeQueryResult>)executeMapper:(id<MeetingsCoreRuntimeQueryResult> (^)(id<MeetingsCoreRuntimeSqlCursor>))mapper __attribute__((swift_name("execute(mapper:)")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
@property (readonly) RowType (^mapper)(id<MeetingsCoreRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end

__attribute__((swift_name("RuntimeQuery")))
@interface MeetingsCoreRuntimeQuery<__covariant RowType> : MeetingsCoreRuntimeExecutableQuery<RowType>
- (instancetype)initWithMapper:(RowType (^)(id<MeetingsCoreRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<MeetingsCoreRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (void)removeListenerListener:(id<MeetingsCoreRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@end

__attribute__((swift_name("RuntimeSqlSchema")))
@protocol MeetingsCoreRuntimeSqlSchema
@required
- (id<MeetingsCoreRuntimeQueryResult>)createDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (id<MeetingsCoreRuntimeQueryResult>)migrateDriver:(id<MeetingsCoreRuntimeSqlDriver>)driver oldVersion:(int64_t)oldVersion newVersion:(int64_t)newVersion callbacks:(MeetingsCoreKotlinArray<MeetingsCoreRuntimeAfterVersion *> *)callbacks __attribute__((swift_name("migrate(driver:oldVersion:newVersion:callbacks:)")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol MeetingsCoreKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<MeetingsCoreKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface MeetingsCoreKotlinArray<T> : MeetingsCoreBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(MeetingsCoreInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<MeetingsCoreKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol MeetingsCoreKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol MeetingsCoreKotlinSuspendFunction1 <MeetingsCoreKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol MeetingsCoreKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<MeetingsCoreKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol MeetingsCoreKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<MeetingsCoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol MeetingsCoreKotlinx_serialization_coreKSerializer <MeetingsCoreKotlinx_serialization_coreSerializationStrategy, MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface MeetingsCoreKotlinRuntimeException : MeetingsCoreKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface MeetingsCoreKotlinIllegalStateException : MeetingsCoreKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface MeetingsCoreKotlinCancellationException : MeetingsCoreKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MeetingsCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface MeetingsCoreKotlinPair<__covariant A, __covariant B> : MeetingsCoreBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (MeetingsCoreKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface MeetingsCoreKotlinx_serialization_jsonJsonElement : MeetingsCoreBase
@property (class, readonly, getter=companion) MeetingsCoreKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface MeetingsCoreKotlinEnumCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol MeetingsCoreKotlinx_coroutines_coreSharedFlow <MeetingsCoreKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol MeetingsCoreKotlinx_coroutines_coreStateFlow <MeetingsCoreKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Rtcp_coreMediaStreamTrack")))
@interface MeetingsCoreRtcp_coreMediaStreamTrack : MeetingsCoreBase
@property (class, readonly, getter=companion) MeetingsCoreRtcp_coreMediaStreamTrackCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)onSetEnabledEnabled:(BOOL)enabled __attribute__((swift_name("onSetEnabled(enabled:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)onStop __attribute__((swift_name("onStop()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)setMuteMuted:(BOOL)muted __attribute__((swift_name("setMute(muted:)")));
- (void)stop __attribute__((swift_name("stop()")));
@property BOOL enabled __attribute__((swift_name("enabled")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) RTCMediaStreamTrack *ios __attribute__((swift_name("ios")));
@property (readonly) MeetingsCoreRtcp_coreMediaStreamTrackKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *label __attribute__((swift_name("label")));
@property (readonly) id<MeetingsCoreKotlinx_coroutines_coreStateFlow> state __attribute__((swift_name("state")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rtcp_coreVideoStreamTrack")))
@interface MeetingsCoreRtcp_coreVideoStreamTrack : MeetingsCoreRtcp_coreMediaStreamTrack
- (void)addSinkSink:(NSObject *)sink __attribute__((swift_name("addSink(sink:)")));
- (void)changeCaptureFormatVideoCaptureSpec:(MeetingsCoreRtcp_coreVideoCaptureSpec *)videoCaptureSpec __attribute__((swift_name("changeCaptureFormat(videoCaptureSpec:)")));
- (MeetingsCoreBoolean * _Nullable)isFrontCam __attribute__((swift_name("isFrontCam()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)onSetEnabledEnabled:(BOOL)enabled __attribute__((swift_name("onSetEnabled(enabled:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)onStop __attribute__((swift_name("onStop()")));
- (void)removeSinkSink:(NSObject *)sink __attribute__((swift_name("removeSink(sink:)")));
- (void)startCapturer __attribute__((swift_name("startCapturer()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)switchCameraDeviceId:(NSString * _Nullable)deviceId completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("switchCamera(deviceId:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rtcp_coreVideoSinkDetails")))
@interface MeetingsCoreRtcp_coreVideoSinkDetails : MeetingsCoreBase
- (instancetype)initWithStreamId:(NSString *)streamId videoView:(NSView *)videoView __attribute__((swift_name("init(streamId:videoView:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *streamId __attribute__((swift_name("streamId")));
@property (readonly) NSView *videoView __attribute__((swift_name("videoView")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol MeetingsCoreKotlinx_serialization_coreSerialFormat
@required
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol MeetingsCoreKotlinx_serialization_coreStringFormat <MeetingsCoreKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface MeetingsCoreKotlinx_serialization_jsonJson : MeetingsCoreBase <MeetingsCoreKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) MeetingsCoreKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(MeetingsCoreKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (MeetingsCoreKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringSerializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (MeetingsCoreKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) MeetingsCoreKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("RuntimeQueryListener")))
@protocol MeetingsCoreRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end

__attribute__((swift_name("RuntimeQueryResult")))
@protocol MeetingsCoreRuntimeQueryResult
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("await(completionHandler:)")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol MeetingsCoreRuntimeSqlPreparedStatement
@required
- (void)bindBooleanIndex:(int32_t)index boolean:(MeetingsCoreBoolean * _Nullable)boolean __attribute__((swift_name("bindBoolean(index:boolean:)")));
- (void)bindBytesIndex:(int32_t)index bytes:(MeetingsCoreKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(MeetingsCoreDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(MeetingsCoreLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol MeetingsCoreRuntimeSqlCursor
@required
- (MeetingsCoreBoolean * _Nullable)getBooleanIndex:(int32_t)index __attribute__((swift_name("getBoolean(index:)")));
- (MeetingsCoreKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (MeetingsCoreDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (MeetingsCoreLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (id<MeetingsCoreRuntimeQueryResult>)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeAfterVersion")))
@interface MeetingsCoreRuntimeAfterVersion : MeetingsCoreBase
- (instancetype)initWithAfterVersion:(int64_t)afterVersion block:(void (^)(id<MeetingsCoreRuntimeSqlDriver>))block __attribute__((swift_name("init(afterVersion:block:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int64_t afterVersion __attribute__((swift_name("afterVersion")));
@property (readonly) void (^block)(id<MeetingsCoreRuntimeSqlDriver>) __attribute__((swift_name("block")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol MeetingsCoreKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol MeetingsCoreKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol MeetingsCoreKotlinx_serialization_coreEncoder
@required
- (id<MeetingsCoreKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<MeetingsCoreKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<MeetingsCoreKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol MeetingsCoreKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<MeetingsCoreKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<MeetingsCoreKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol MeetingsCoreKotlinx_serialization_coreDecoder
@required
- (id<MeetingsCoreKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<MeetingsCoreKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (MeetingsCoreKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface MeetingsCoreKotlinx_serialization_jsonJsonElementCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rtcp_coreMediaStreamTrack.Companion")))
@interface MeetingsCoreRtcp_coreMediaStreamTrackCompanion : MeetingsCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreRtcp_coreMediaStreamTrackCompanion *shared __attribute__((swift_name("shared")));
- (MeetingsCoreRtcp_coreMediaStreamTrack *)createCommonIos:(RTCMediaStreamTrack *)ios __attribute__((swift_name("createCommon(ios:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rtcp_coreMediaStreamTrackKind")))
@interface MeetingsCoreRtcp_coreMediaStreamTrackKind : MeetingsCoreKotlinEnum<MeetingsCoreRtcp_coreMediaStreamTrackKind *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MeetingsCoreRtcp_coreMediaStreamTrackKind *audio __attribute__((swift_name("audio")));
@property (class, readonly) MeetingsCoreRtcp_coreMediaStreamTrackKind *video __attribute__((swift_name("video")));
+ (MeetingsCoreKotlinArray<MeetingsCoreRtcp_coreMediaStreamTrackKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MeetingsCoreRtcp_coreMediaStreamTrackKind *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rtcp_coreVideoCaptureSpec")))
@interface MeetingsCoreRtcp_coreVideoCaptureSpec : MeetingsCoreBase
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height fps:(int32_t)fps __attribute__((swift_name("init(width:height:fps:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int32_t fps __attribute__((swift_name("fps")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface MeetingsCoreKotlinx_serialization_coreSerializersModule : MeetingsCoreBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<MeetingsCoreKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MeetingsCoreKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<MeetingsCoreKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<MeetingsCoreKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<MeetingsCoreKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<MeetingsCoreKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface MeetingsCoreKotlinx_serialization_jsonJsonDefault : MeetingsCoreKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MeetingsCoreKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface MeetingsCoreKotlinx_serialization_jsonJsonConfiguration : MeetingsCoreBase
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<MeetingsCoreKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface MeetingsCoreKotlinByteArray : MeetingsCoreBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(MeetingsCoreByte *(^)(MeetingsCoreInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (MeetingsCoreKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol MeetingsCoreKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<MeetingsCoreKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol MeetingsCoreKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface MeetingsCoreKotlinx_serialization_coreSerialKind : MeetingsCoreBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol MeetingsCoreKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<MeetingsCoreKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) MeetingsCoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface MeetingsCoreKotlinNothing : MeetingsCoreBase
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol MeetingsCoreKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<MeetingsCoreKotlinKClass>)kClass provider:(id<MeetingsCoreKotlinx_serialization_coreKSerializer> (^)(NSArray<id<MeetingsCoreKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<MeetingsCoreKotlinKClass>)kClass serializer:(id<MeetingsCoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<MeetingsCoreKotlinKClass>)baseClass actualClass:(id<MeetingsCoreKotlinKClass>)actualClass actualSerializer:(id<MeetingsCoreKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<MeetingsCoreKotlinKClass>)baseClass defaultDeserializerProvider:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<MeetingsCoreKotlinKClass>)baseClass defaultDeserializerProvider:(id<MeetingsCoreKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<MeetingsCoreKotlinKClass>)baseClass defaultSerializerProvider:(id<MeetingsCoreKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol MeetingsCoreKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol MeetingsCoreKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol MeetingsCoreKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol MeetingsCoreKotlinKClass <MeetingsCoreKotlinKDeclarationContainer, MeetingsCoreKotlinKAnnotatedElement, MeetingsCoreKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol MeetingsCoreKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<MeetingsCoreKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface MeetingsCoreKotlinByteIterator : MeetingsCoreBase <MeetingsCoreKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MeetingsCoreByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
