//
//  MobilistenCalls.h
//  MobilistenCalls
//
//  Created by Kishore Kumar A on 21/05/25.
//

#import <Foundation/Foundation.h>

//! Project version number for MobilistenCalls.
FOUNDATION_EXPORT double MobilistenCallsVersionNumber;

//! Project version string for MobilistenCalls.
FOUNDATION_EXPORT const unsigned char MobilistenCallsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MobilistenCalls/PublicHeader.h>


